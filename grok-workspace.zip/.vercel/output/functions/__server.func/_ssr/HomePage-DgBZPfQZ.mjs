import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as ArrowLeft } from "../_libs/lucide-react.mjs";
import { a as FLOW, f as Reveal, g as cn, h as WHY, i as COMPANY, l as PROCESS, m as TAGLINE, n as BUILD_CARDS, r as Button, s as PATH_STEPS, u as PROJECTS } from "./SiteShell-C2EYCLcb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/HomePage-DgBZPfQZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function BuildCards() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-navy py-20 text-cream md:py-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-5 lg:px-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-[0.2em] text-teal-soft",
					children: "توانمندی‌ها"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "ambient-halo mt-4 max-w-3xl text-[36px] font-semibold leading-[1.3] md:text-[52px]",
					children: "چهار مسیر، یک نگاه صنعتی"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-5 max-w-2xl text-[16px] leading-[1.9] text-cream/70",
					children: "از تعمیرات و ساخت تا پژوهش و تجهیزات تخصصی؛ هر مسیر از تجربه میدان عملیات شکل گرفته است."
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-12 grid gap-5 sm:grid-cols-2",
				children: BUILD_CARDS.map((card, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: i * 80,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: card.href,
						className: "group relative block aspect-[16/11] overflow-hidden rounded-xl",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: card.img,
								alt: "",
								className: "absolute inset-0 size-full object-cover transition-[transform,filter] duration-500 ease-out group-hover:scale-110 group-hover:brightness-[0.3] max-md:scale-105 max-md:brightness-[0.45]"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-navy/20 transition-colors duration-500 group-hover:bg-navy/55 max-md:bg-navy/40" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "absolute inset-0 flex flex-col justify-end p-6 md:p-8",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "latin text-[11px] tracking-[0.2em] text-teal-soft",
										children: card.kicker
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "mt-2 text-[24px] font-semibold md:text-[28px]",
										children: card.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "mt-4 inline-flex h-11 w-fit items-center gap-2 rounded-md bg-amber px-4 text-[13px] font-medium text-navy opacity-100 transition-[opacity,transform] duration-500 ease-out md:translate-y-2 md:opacity-0 md:group-hover:translate-y-0 md:group-hover:opacity-100",
										children: ["جزئیات بیشتر", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" })]
									})
								]
							})
						]
					})
				}, card.href))
			})]
		})
	});
}
function CountUp({ to, prefix = "", suffix = "", className, duration = 1400 }) {
	const ref = (0, import_react.useRef)(null);
	const [value, setValue] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		const el = ref.current;
		if (!el) return;
		const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		let started = false;
		let frame = 0;
		const run = () => {
			if (started) return;
			started = true;
			if (reduced) {
				setValue(to);
				return;
			}
			const start = performance.now();
			const tick = (now) => {
				const t = Math.min(1, (now - start) / duration);
				const eased = 1 - (1 - t) ** 3;
				setValue(Math.round(eased * to));
				if (t < 1) frame = requestAnimationFrame(tick);
			};
			frame = requestAnimationFrame(tick);
		};
		const visible = () => {
			const r = el.getBoundingClientRect();
			return r.bottom > 60 && r.top < window.innerHeight - 40;
		};
		const io = new IntersectionObserver(([e]) => {
			if (e.isIntersecting) run();
		}, {
			threshold: .05,
			rootMargin: "0px 0px -8% 0px"
		});
		io.observe(el);
		if (visible()) run();
		const onScroll = () => {
			if (visible()) run();
		};
		window.addEventListener("scroll", onScroll, { passive: true });
		const fallback = window.setTimeout(() => {
			if (visible()) run();
		}, 600);
		return () => {
			io.disconnect();
			window.removeEventListener("scroll", onScroll);
			window.clearTimeout(fallback);
			cancelAnimationFrame(frame);
		};
	}, [to, duration]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		ref,
		className: cn("tabular-nums latin", className),
		children: [
			prefix,
			value,
			suffix
		]
	});
}
function WordReveal({ text, className, delay = 0, as: Tag = "h1" }) {
	const words = text.split(" ").filter(Boolean);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, {
		className: cn(className),
		children: words.map((word, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "word-reveal",
			style: { animationDelay: `${delay + i * 80}ms` },
			children: [word, i < words.length - 1 ? "\xA0" : ""]
		}, `${word}-${i}`))
	});
}
function LineReveal({ children, className, delay = 0, as: Tag = "p" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, {
		className: cn("line-reveal", className),
		style: { animationDelay: `${delay}ms` },
		children
	});
}
function HomePage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stats, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AboutBand, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Path, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BuildCards, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bridge, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Product, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Problem, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(How, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BeforeAfter, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tests, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Value, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProjectsPreview, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhyUs, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Vision, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FinalCta, {})
	] });
}
function Hero() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative min-h-dvh overflow-hidden bg-navy text-cream",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/images/hero-refinery.jpg",
				alt: "",
				className: "absolute inset-0 size-full object-cover"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-navy/72" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-navy via-navy/40 to-navy/55" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "glow-orb glow-breathe -right-10 top-24 size-[520px] md:size-[640px]" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "glow-orb-amber bottom-10 left-0 size-[280px] opacity-60" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto flex min-h-dvh max-w-7xl flex-col justify-end px-5 pb-16 pt-40 lg:justify-center lg:px-8 lg:pb-24 lg:pt-28",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-4xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LineReveal, {
							className: "text-[13px] tracking-[0.22em] text-teal-soft",
							delay: 80,
							as: "p",
							children: COMPANY
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "line-reveal mt-4 h-px w-16 bg-teal glow-line",
							style: { animationDelay: "180ms" }
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WordReveal, {
							text: TAGLINE,
							className: "ambient-halo mt-6 text-[42px] font-semibold leading-[1.2] sm:text-[56px] lg:text-[80px]",
							delay: 220
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LineReveal, {
							className: "mt-7 max-w-2xl text-[16px] leading-[1.9] text-cream/78 md:text-[18px]",
							delay: 720,
							as: "p",
							children: "بیش از دو دهه تجربه عملی در صنایع نفت، گاز و پتروشیمی، پشتوانه فعالیت ما در حوزه خدمات فنی، تعمیرات، ساخت قطعات و تجهیزات تخصصی و توسعه راهکارهای فناورانه است."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LineReveal, {
							className: "mt-4 max-w-2xl text-[15px] leading-[1.9] text-cream/62",
							delay: 860,
							as: "p",
							children: "ما از دل عملیات صنعتی آمده‌ایم؛ از جایی که محدودیت زمان، پیچیدگی تجهیزات و نیاز به راهکارهای قابل اتکا، اهمیت تجربه و مهندسی را مشخص می‌کند."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "line-reveal mt-10 flex flex-col gap-3 sm:flex-row",
							style: { animationDelay: "980ms" },
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								href: "/about",
								variant: "amber",
								size: "lg",
								children: ["معرفی شرکت", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								href: "/navvab",
								variant: "ghost",
								size: "lg",
								children: "مشاهده محصولات Navvab"
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "line-reveal mt-14 text-[13px] text-cream/50",
					style: { animationDelay: "1100ms" },
					children: "کاوشگران فنون توسعه نفت؛ از تجربه عملیاتی تا راهکار مهندسی."
				})]
			})
		]
	});
}
function Stats() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative overflow-hidden bg-navy-deep py-16 text-cream md:py-20",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "glow-orb right-1/4 top-0 size-[320px] opacity-50" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "relative mx-auto grid max-w-7xl gap-8 px-5 sm:grid-cols-2 lg:grid-cols-4 lg:gap-6 lg:px-8",
			children: [
				{
					label: "سال تجربه صنعتی",
					value: 20,
					prefix: "+",
					suffix: ""
				},
				{
					label: "سال آغاز فعالیت شرکت",
					value: 1396,
					prefix: "",
					suffix: ""
				},
				{
					label: "حوزه فعالیت",
					value: 0,
					custom: "نفت، گاز و پتروشیمی"
				},
				{
					label: "محصول شاخص Navvab",
					value: 1,
					prefix: "0",
					suffix: ""
				}
			].map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				delay: i * 90,
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "ambient-halo text-[40px] font-semibold leading-[1.15] text-cream md:text-[48px]",
					children: item.custom ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-[22px] leading-snug md:text-[26px]",
						children: item.custom
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CountUp, {
						to: item.value,
						prefix: item.prefix,
						suffix: item.suffix
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-[13px] text-cream/55",
					children: item.label
				})]
			}, item.label))
		})]
	});
}
function AboutBand() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-soft py-20 md:py-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-7xl items-center gap-12 px-5 lg:grid-cols-12 lg:px-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				className: "lg:col-span-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-[0.2em] text-teal",
						children: "درباره شرکت"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-4 text-[36px] font-semibold leading-[1.3] text-navy md:text-[52px]",
						children: "تجربه‌ای شکل‌گرفته در دل صنعت"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-5 h-px w-14 bg-amber" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 space-y-5 text-[16px] leading-[1.9] text-ink/80 md:text-[17px]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "کاوشگران فنون توسعه نفت در سال ۱۳۹۶ فعالیت خود را آغاز کرد؛ اما سابقه و تجربه شکل‌دهنده این مجموعه به بیش از دو دهه فعالیت و تجربه عملی در صنعت بازمی‌گردد." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "در طول این سال‌ها، حضور در پروژه‌های مختلف نفت، گاز و پتروشیمی، ما را با طیف گسترده‌ای از فعالیت‌های اجرایی و فنی آشنا کرده است؛ از تعمیرات و نگهداری تجهیزات و واحدها گرفته تا نصب و راه‌اندازی، ساخت قطعات خاص و طراحی ابزارآلات مورد نیاز عملیات." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[18px] font-medium text-navy",
								children: "مسئله واقعی صنعت را باید از نزدیک شناخت تا بتوان برای آن راهکار واقعی ساخت."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "به همین دلیل، فعالیت ما تنها به اجرای خدمات محدود نمانده و مسیر پژوهش، توسعه و ساخت تجهیزات تخصصی نیز در مجموعه شکل گرفته است." })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							href: "/about",
							variant: "navy",
							children: ["داستان مجموعه", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" })]
						})
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				delay: 120,
				className: "relative lg:col-span-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "glow-orb -left-6 top-8 size-48 opacity-80" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-hidden rounded-xl",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/images/workshop.jpg",
							alt: "کارگاه ساخت و مهندسی تجهیزات صنعتی",
							className: "aspect-[16/11] w-full object-cover"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 overflow-hidden rounded-xl",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/images/piping.jpg",
							alt: "لوله‌کشی صنعتی در واحد پالایش",
							className: "aspect-[16/7] w-full object-cover"
						})
					})
				]
			})]
		})
	});
}
function Path() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-cream py-20 md:py-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-5 lg:px-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-[0.2em] text-teal",
						children: "یک نگاه به مسیر ما"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-4 max-w-3xl text-[36px] font-semibold leading-[1.3] text-navy md:text-[52px]",
						children: "از مسئله صنعت تا راهکار"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 max-w-2xl text-[16px] leading-[1.9] text-ink/75",
						children: "بسیاری از راهکارهای صنعتی زمانی شکل می‌گیرند که یک مسئله واقعی، بارها در عملیات تکرار شده باشد. تجربه حضور در تعمیرات اساسی و عملیات اجرایی، این فرصت را ایجاد کرد که برخی چالش‌ها نه فقط از نگاه یک مجری، بلکه از نگاه یک توسعه‌دهنده مورد بررسی قرار گیرند."
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
					className: "mt-14",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative hidden lg:block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "draw-line absolute top-5 right-0 left-0 h-px bg-teal/50 glow-line" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
							className: "relative grid grid-cols-7 gap-3",
							children: PATH_STEPS.map((step, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex flex-col items-center text-center",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "path-dot relative z-10 size-2.5 rounded-full bg-teal",
										style: { animationDelay: `${i * 90}ms` }
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "latin mt-5 text-[11px] text-muted",
										children: String(i + 1).padStart(2, "0")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-1 text-[15px] font-medium text-navy",
										children: step
									})
								]
							}, step))
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "space-y-0 lg:hidden",
						children: PATH_STEPS.map((step, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col items-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2.5 rounded-full bg-teal" }), i < PATH_STEPS.length - 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-px flex-1 bg-teal/30" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "pb-6 text-[16px] font-medium text-navy",
								children: step
							})]
						}, step))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
					delay: 80,
					className: "mt-12 max-w-2xl space-y-3 text-[15px] leading-[1.9] text-ink/75",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "مسئله شناسایی می‌شود. شرایط واقعی عملیات بررسی می‌شود. راهکارهای ممکن مورد ارزیابی قرار می‌گیرند." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "طراحی و ساخت انجام می‌شود. نمونه ساخته‌شده مورد آزمون قرار می‌گیرد. و در نهایت، راهکار برای استفاده در شرایط واقعی صنعت آماده می‌شود." })]
				})
			]
		})
	});
}
function Bridge() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-cream py-20 md:py-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-7xl items-center gap-12 px-5 lg:grid-cols-2 lg:px-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/images/column.jpg",
				alt: "ستون تقطیر در مجتمع صنعتی",
				className: "aspect-[3/4] w-full rounded-xl object-cover lg:aspect-[4/5]"
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				delay: 100,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-[0.2em] text-teal",
						children: "نقطه اتصال تجربه و فناوری"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-4 text-[36px] font-semibold leading-[1.3] text-navy md:text-[48px]",
						children: "وقتی تجربه، به توسعه یک راهکار منجر می‌شود"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 space-y-5 text-[16px] leading-[1.9] text-ink/80",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "تجربه صنعتی زمانی ارزش بیشتری پیدا می‌کند که بتوان از آن برای ساخت راهکارهای جدید استفاده کرد." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "در جریان عملیات تعمیرات اساسی، برخی فعالیت‌ها زمان زیادی از پروژه می‌گیرند، نیروی انسانی قابل توجهی نیاز دارند و می‌توانند بر برنامه کلی راه‌اندازی اثرگذار باشند." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[20px] font-medium text-navy",
								children: "هدف، جایگزین کردن تجربه با فناوری نیست؛ هدف، تبدیل تجربه به فناوری است."
							})
						]
					})
				]
			})]
		})
	});
}
function Product() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-soft py-20 md:py-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-7xl items-center gap-12 px-5 lg:grid-cols-12 lg:px-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				className: "relative lg:col-span-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "glow-orb -right-8 top-10 size-56" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-hidden rounded-xl",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/images/product-device.jpg",
						alt: "دستگاه وکیوم شارژ مولکولارسیو روی رآکتور",
						className: "aspect-[4/3] w-full object-cover"
					})
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				delay: 80,
				className: "lg:col-span-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-[0.2em] text-teal",
						children: "محصول شاخص"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-4 text-[32px] font-semibold leading-[1.3] text-navy md:text-[44px]",
						children: "دستگاه وکیوم شارژ مولکولارسیو"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 text-[18px] font-medium leading-[1.7] text-blue",
						children: "فناوری نوین برای کاهش زمان عملیات شارژ و بازگشت سریع‌تر رآکتورها به مدار"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 text-[16px] leading-[1.9] text-ink/78",
						children: "شارژ مولکولارسیو، کاتالیست و مواد مشابه در رآکتورها، یکی از فعالیت‌های مهم در زمان تعمیرات اساسی واحدهای صنعتی است. دستگاه وکیوم شارژ مولکولارسیو با استفاده از یک سیستم پنوماتیک و مکش، روش متفاوتی برای انتقال مواد به داخل رآکتور ارائه می‌کند."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-10 grid grid-cols-2 gap-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "ambient-halo text-[28px] font-semibold text-navy md:text-[36px]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "latin",
									children: "18–24"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[16px] font-normal text-muted",
									children: " ساعت"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-[13px] text-muted",
								children: "روش سنتی"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "ambient-halo text-[28px] font-semibold text-teal md:text-[36px]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "latin",
									children: "~4"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[16px] font-normal text-muted",
									children: " ساعت"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-[13px] text-muted",
								children: "روش جدید"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-[28px] font-semibold text-navy md:text-[36px]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "latin",
									children: "~25"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[16px] font-normal text-muted",
									children: " نفر"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-[13px] text-muted",
								children: "نیروی سنتی"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-[28px] font-semibold text-teal md:text-[36px]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "latin",
									children: "~3"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[16px] font-normal text-muted",
									children: " نفر"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-[13px] text-muted",
								children: "نیروی جدید"
							})] })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-8 text-[14px] leading-[1.8] text-ink/65",
						children: "امکان اجرای هم‌زمان عملیات برای سه رآکتور در شرایط موردنظر."
					})
				]
			})]
		})
	});
}
function Problem() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-cream py-20 md:py-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto max-w-7xl px-5 lg:px-8",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				className: "max-w-3xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-[0.2em] text-teal",
						children: "مسئله چیست؟"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-4 text-[36px] font-semibold leading-[1.3] text-navy md:text-[52px]",
						children: "وقتی زمان، بخشی از هزینه عملیات است"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 space-y-5 text-[16px] leading-[1.9] text-ink/80",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "در عملیات تعمیرات اساسی، زمان توقف تجهیزات اهمیت زیادی دارد. شارژ رآکتورها یکی از فعالیت‌هایی است که در صورت اجرای دستی، می‌تواند ساعت‌ها به طول انجامد و نیروی انسانی قابل توجهی را درگیر کند." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "بنابراین مسئله فقط انتقال مواد نیست. مسئله اصلی، زمان، نیروی انسانی، شرایط اجرا و بازگشت سریع‌تر رآکتور به مدار است." })]
					})
				]
			})
		})
	});
}
function How() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-navy py-20 text-cream md:py-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-5 lg:px-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-[0.2em] text-teal-soft",
					children: "چگونه کار می‌کند؟"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "ambient-halo mt-4 max-w-3xl text-[32px] font-semibold leading-[1.3] md:text-[48px]",
					children: "یک فرآیند ساده، برای یک عملیات پیچیده"
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					className: "mt-12",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-4 sm:grid-cols-3 lg:flex lg:items-center",
						children: FLOW.map((f, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center lg:flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col items-center text-center lg:w-full",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid size-11 place-items-center rounded-full border border-teal/50 text-[12px] text-teal-soft",
									children: String(i + 1).padStart(2, "0")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-[13px] leading-snug",
									children: f
								})]
							}), i < FLOW.length - 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-2 hidden h-px flex-1 bg-teal/40 glow-line lg:block" })]
						}, f))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-14 grid gap-5 md:grid-cols-2 lg:grid-cols-3",
					children: PROCESS.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
						delay: i * 60,
						className: "rounded-xl border border-white/8 bg-white/4 p-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "latin text-teal-soft",
								children: p.n
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-2 text-[20px] font-medium",
								children: p.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-[14.5px] leading-[1.85] text-cream/70",
								children: p.body
							})
						]
					}, p.n))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					className: "mt-8 text-[14px] text-cream/55",
					children: "تمام این فرآیند با تمرکز بر شرایط واقعی عملیات صنعتی طراحی شده است. عملکرد دستگاه بدون نیاز به برق است."
				})
			]
		})
	});
}
function BeforeAfter() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "grid lg:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "bg-graphite px-5 py-16 text-cream md:px-12 md:py-24",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-[0.2em] text-cream/45",
					children: "روش سنتی"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-[32px] font-semibold md:text-[40px]",
					children: "انتقال دستی"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 max-w-md text-[16px] leading-[1.9] text-cream/70",
					children: "در روش سنتی، عملیات شارژ به شکل دستی انجام می‌شود. این روش به تعداد زیادی نیروی انسانی نیاز دارد و زمان اجرای آن طولانی است. در شرایطی که چند رآکتور در یک مجموعه وجود داشته باشد، عملیات معمولاً به‌صورت مرحله‌ای انجام می‌شود."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "mt-10 space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-[13px] text-cream/45",
						children: "زمان"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "text-[28px] font-semibold",
						children: "۱۸–۲۴ ساعت"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-[13px] text-cream/45",
						children: "نیروی انسانی"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "text-[28px] font-semibold",
						children: "حدود ۲۵ نفر"
					})] })]
				})
			] })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative overflow-hidden bg-navy px-5 py-16 text-cream md:px-12 md:py-24",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "glow-orb glow-breathe -left-10 top-0 size-[360px]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				className: "relative",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-[0.2em] text-teal-soft",
						children: "روش جدید"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "ambient-halo mt-4 text-[32px] font-semibold md:text-[40px]",
						children: "مکش پنوماتیک"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 max-w-md text-[16px] leading-[1.9] text-cream/75",
						children: "در روش جدید، دستگاه وکیوم شارژ مولکولارسیو با استفاده از مکش پنوماتیک، انتقال مواد را انجام می‌دهد. بر اساس آزمون‌های انجام‌شده، زمان و نیروی انسانی به‌طور محسوس کاهش یافته است."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-10 space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-[13px] text-cream/45",
								children: "زمان"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "text-[28px] font-semibold text-teal-soft",
								children: "حدود ۴ ساعت"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-[13px] text-cream/45",
								children: "نیروی انسانی"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "text-[28px] font-semibold text-teal-soft",
								children: "حدود ۳ نفر"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-[13px] text-cream/45",
								children: "هم‌زمانی"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "text-[22px] font-medium",
								children: "تا سه رآکتور در شرایط موردنظر"
							})] })
						]
					})
				]
			})]
		})]
	});
}
function Tests() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-soft py-20 md:py-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-7xl items-center gap-12 px-5 lg:grid-cols-2 lg:px-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-[0.2em] text-teal",
					children: "نتایج آزمون‌ها"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-[32px] font-semibold leading-[1.3] text-navy md:text-[44px]",
					children: "نتیجه‌ای که باید در میدان عمل دیده شود"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 space-y-5 text-[16px] leading-[1.9] text-ink/80",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "این تجهیز با هدف استفاده در شرایط واقعی صنعت طراحی و ساخته شده است." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "طراحی و ساخت دستگاه توسط کاوشگران فنون توسعه نفت انجام شده است." })]
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				delay: 80,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/images/catalyst.jpg",
					alt: "دانه‌های مولکولارسیو",
					className: "aspect-[4/3] w-full rounded-xl object-cover"
				})
			})]
		})
	});
}
function Value() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-cream py-20 md:py-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto max-w-7xl px-5 lg:px-8",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-[0.2em] text-teal",
					children: "ارزش واقعی فناوری"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 max-w-3xl text-[36px] font-semibold leading-[1.25] text-navy md:text-[56px]",
					children: "زمان کمتر، بازگشت سریع‌تر به مدار"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-10 max-w-xl text-[18px] leading-[1.9] text-ink/75",
					children: "ارزش اصلی این تجهیز تنها در نحوه انتقال مواد نیست. کاهش زمان عملیات شارژ می‌تواند بخشی از زمان توقف رآکتور را کاهش دهد و مسیر بازگشت آن به مدار را کوتاه‌تر کند."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-10 max-w-4xl text-[28px] font-semibold leading-[1.45] text-navy md:text-[40px]",
					children: "کاهش زمان عملیات و کمک به بازگشت سریع‌تر رآکتورها به مدار."
				})
			] })
		})
	});
}
function ProjectsPreview() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-soft py-20 md:py-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-5 lg:px-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				className: "flex flex-col gap-4 md:flex-row md:items-end md:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-[0.2em] text-teal",
					children: "تجربه پروژه"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-[32px] font-semibold text-navy md:text-[44px]",
					children: "تجربه‌ای که در نقاط مختلف صنعت شکل گرفته است"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					href: "/projects",
					variant: "outline",
					children: ["همه سوابق", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" })]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3",
				children: PROJECTS.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
					delay: i * 60,
					as: "article",
					className: "group overflow-hidden rounded-xl bg-cream shadow-[var(--shadow-card)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-hidden",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: p.img,
							alt: p.name,
							className: "aspect-[16/10] w-full object-cover transition-transform duration-500 group-hover:scale-[1.03]"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[12px] text-teal",
								children: p.tag
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-1 text-[20px] font-medium text-navy",
								children: p.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-[13px] text-muted",
								children: p.place
							})
						]
					})]
				}, p.name))
			})]
		})
	});
}
function WhyUs() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-cream py-20 md:py-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-5 lg:px-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-[0.2em] text-teal",
				children: "چرا کاوشگران فنون توسعه نفت؟"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-4 text-[32px] font-semibold text-navy md:text-[48px]",
				children: "تجربه، مهندسی و شناخت عملیات"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-12 grid gap-x-10 gap-y-12 md:grid-cols-2 lg:grid-cols-5",
				children: WHY.map((w, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
					delay: i * 70,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "latin text-[12px] text-teal",
							children: String(i + 1).padStart(2, "0")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-3 text-[20px] font-medium text-navy",
							children: w.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-[14.5px] leading-[1.85] text-ink/70",
							children: w.body
						})
					]
				}, w.title))
			})]
		})
	});
}
function Vision() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/images/night-refinery.jpg",
				alt: "",
				className: "absolute inset-0 size-full object-cover"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-navy/78" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "glow-orb left-1/3 top-10 size-[420px] opacity-60" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative mx-auto max-w-7xl px-5 py-24 lg:px-8 md:py-32",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-[0.2em] text-teal-soft",
						children: "نگاه ما به صنعت"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "ambient-halo mt-5 max-w-4xl text-[32px] font-semibold leading-[1.35] text-cream md:text-[48px]",
						children: "فناوری زمانی ارزشمند است که یک مسئله واقعی را حل کند"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-8 max-w-2xl text-[16px] leading-[1.9] text-cream/75",
						children: "ما فناوری را جدا از صنعت تعریف نمی‌کنیم. هر راهکار باید از یک نیاز واقعی شروع شود، شرایط اجرایی را در نظر بگیرد و در نهایت بتواند در محیط صنعتی مورد استفاده قرار گیرد."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 max-w-2xl text-[16px] leading-[1.9] text-cream/75",
						children: "طراحی، ساخت، آزمون و آماده‌سازی برای اجرای صنعتی، بخش‌های یک مسیر واحد هستند. توسعه ادامه دارد."
					})
				] })
			})
		]
	});
}
function FinalCta() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative overflow-hidden bg-navy py-24 text-cream md:py-32",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "glow-orb glow-breathe right-0 top-0 size-[480px]" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "glow-orb-amber bottom-0 left-10 size-[260px]" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative mx-auto max-w-7xl px-5 text-center lg:px-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "ambient-halo text-[40px] font-semibold md:text-[64px]",
						children: "یک مسئله صنعتی دارید؟"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mx-auto mt-5 max-w-xl text-[18px] leading-[1.9] text-cream/72",
						children: "شاید نقطه شروع فناوری بعدی ما باشد."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-10 flex flex-col items-center justify-center gap-3 sm:flex-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							href: "/contact",
							variant: "amber",
							size: "lg",
							children: "ارتباط با ما"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							href: "/navvab",
							variant: "ghost",
							size: "lg",
							children: "مشاهده محصولات Navvab"
						})]
					})
				] })
			})
		]
	});
}
//#endregion
export { FinalCta as n, HomePage as r, BuildCards as t };
