import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime, b as Link, p as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Volume2, t as VolumeX } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/SiteShell-C2EYCLcb.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function Reveal({ children, className, delay = 0, as: Tag = "div" }) {
	const ref = (0, import_react.useRef)(null);
	const [shown, setShown] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const el = ref.current;
		if (!el) return;
		if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
			setShown(true);
			return;
		}
		const io = new IntersectionObserver(([entry]) => {
			if (entry.isIntersecting) {
				setShown(true);
				io.disconnect();
			}
		}, {
			threshold: .14,
			rootMargin: "0px 0px -8% 0px"
		});
		io.observe(el);
		return () => io.disconnect();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, {
		ref,
		className: cn("reveal", shown && "is-in", className),
		style: { transitionDelay: `${delay}ms` },
		children
	});
}
var COMPANY = "کاوشگران فنون توسعه نفت";
var TAGLINE = "تجربه صنعت، توسعه فناوری";
var MANIFESTO = "تجربه‌ای که از دل صنعت آمده، فناوری‌ای که برای صنعت ساخته شده است.";
var ADDRESS = "کرج، انتهای خیابان شهدای جهاد دانشگاهی، پارک علم و فناوری البرز";
var POSTAL = "۳۱۹۷۹۹۶۶۶۲";
var NAV = [
	{
		href: "/",
		label: "صفحه اصلی"
	},
	{
		href: "/about",
		label: "درباره ما"
	},
	{
		href: "/services",
		label: "خدمات"
	},
	{
		href: "/navvab",
		label: "Navvab"
	},
	{
		href: "/projects",
		label: "پروژه‌ها"
	},
	{
		href: "/knowledge",
		label: "دانش و تجربه"
	},
	{
		href: "/contact",
		label: "تماس با ما"
	}
];
var BUILD_CARDS = [
	{
		title: "برند نواب",
		href: "/navvab",
		img: "/images/product-device.jpg",
		kicker: "NAVVAB"
	},
	{
		title: "تعمیرات و نگهداری",
		href: "/maintenance",
		img: "/images/piping.jpg",
		kicker: "خدمات اجرایی"
	},
	{
		title: "ساخت قطعات",
		href: "/parts",
		img: "/images/workshop.jpg",
		kicker: "مهندسی ساخت"
	},
	{
		title: "پژوهش و توسعه",
		href: "/rd",
		img: "/images/column.jpg",
		kicker: "از ایده تا فناوری"
	}
];
var SERVICES = [
	{
		title: "تعمیرات و نگهداری",
		href: "/maintenance",
		body: "ارائه خدمات فنی در حوزه تعمیرات، نگهداری و اورهال تجهیزات و واحدهای صنعتی نفت، گاز و پتروشیمی؛ از تعمیرات جاری تا تعمیرات اساسی، نصب و راه‌اندازی و فعالیت‌های تخصصی در سایت.",
		icon: "wrench"
	},
	{
		title: "ساخت قطعات",
		href: "/parts",
		body: "مهندسی معکوس، طراحی و ساخت قطعات و تجهیزات تخصصی؛ به‌ویژه در مواردی که تأمین قطعه با محدودیت، زمان طولانی یا پیچیدگی همراه است.",
		icon: "gear"
	},
	{
		title: "پژوهش و توسعه",
		href: "/rd",
		body: "بررسی مسائل و نیازهای موجود در صنعت و تبدیل ایده به طراحی، نمونه‌سازی و محصول قابل استفاده.",
		icon: "lab"
	},
	{
		title: "برند نواب",
		href: "/navvab",
		body: "Navvab برند محصولات و تجهیزات تخصصی توسعه‌یافته توسط کاوشگران فنون توسعه نفت است. محصول شاخص: دستگاه وکیوم شارژ مولکولارسیو.",
		icon: "plant"
	}
];
var PATH_STEPS = [
	"تجربه",
	"شناخت مسئله",
	"پژوهش و توسعه",
	"طراحی",
	"ساخت",
	"آزمون",
	"اجرای صنعتی"
];
var PROCESS = [
	{
		n: "۰۱",
		title: "نصب دستگاه",
		body: "دستگاه با استفاده از جرثقیل به قسمت بالایی رآکتور منتقل شده و از طریق فلنج مناسب در محل موردنظر نصب می‌شود."
	},
	{
		n: "۰۲",
		title: "اتصال هوای فشرده",
		body: "یک خط هوای فشرده موجود در سایت، با فشار حدود ۷ بار، به ورودی دستگاه متصل می‌شود."
	},
	{
		n: "۰۳",
		title: "ایجاد مکش",
		body: "سیستم اجکتور پنوماتیک دستگاه با استفاده از هوای فشرده، مکش لازم برای انتقال مواد را ایجاد می‌کند."
	},
	{
		n: "۰۴",
		title: "آماده‌سازی مواد",
		body: "مولکولارسیو، کاتالیست یا سایر مواد موردنظر در ظروف مناسب در سطح زمین قرار می‌گیرند."
	},
	{
		n: "۰۵",
		title: "انتقال مواد",
		body: "مواد از طریق شیلنگ مناسب و آنتی‌استاتیک به سیستم مکش متصل شده و به سمت دستگاه منتقل می‌شوند."
	},
	{
		n: "۰۶",
		title: "ورود به رآکتور",
		body: "مواد پس از رسیدن به دستگاه، به داخل رآکتور هدایت می‌شوند و فرآیند شارژ ادامه پیدا می‌کند."
	}
];
var FLOW = [
	"مخزن مواد",
	"شیلنگ آنتی‌استاتیک",
	"سیستم مکش",
	"انتقال پنوماتیک",
	"دستگاه در بالای رآکتور",
	"ورود مواد به رآکتور"
];
var WHY = [
	{
		title: "تجربه عملیاتی",
		body: "سال‌ها حضور در پروژه‌های صنعتی، شناخت ما را از شرایط واقعی اجرا شکل داده است."
	},
	{
		title: "شناخت مسئله",
		body: "بخشی از مسیر توسعه محصولات، از مشکلاتی آغاز می‌شود که در جریان عملیات با آن‌ها مواجه شده‌ایم."
	},
	{
		title: "توان طراحی و ساخت",
		body: "ایده زمانی ارزشمند است که بتوان آن را به یک تجهیز قابل استفاده تبدیل کرد."
	},
	{
		title: "نگاه توسعه‌ای",
		body: "ما تلاش می‌کنیم بخشی از نیازهای صنعت را از مسیر پژوهش، طراحی و ساخت پاسخ دهیم."
	},
	{
		title: "توجه به عملکرد",
		body: "راهکارهای صنعتی باید در شرایط واقعی قابل استفاده باشند و ارزش عملیاتی ایجاد کنند."
	}
];
var PROJECTS = [
	{
		name: "پالایشگاه ستاره خلیج فارس",
		place: "بندرعباس",
		img: "/images/coastal-plant.jpg",
		tag: "نفت و پالایش"
	},
	{
		name: "پالایشگاه تبریز",
		place: "تبریز",
		img: "/images/night-refinery.jpg",
		tag: "تعمیرات و نگهداری"
	},
	{
		name: "پالایشگاه پارسیان",
		place: "پارسیان",
		img: "/images/column.jpg",
		tag: "گاز"
	},
	{
		name: "منطقه دارخوین",
		place: "خوزستان",
		img: "/images/piping.jpg",
		tag: "عملیات میدانی"
	},
	{
		name: "پارس جنوبی، عسلویه",
		place: "عسلویه",
		img: "/images/hero-refinery.jpg",
		tag: "پتروشیمی و گاز"
	},
	{
		name: "کنگان و مجموعه‌های صنعتی",
		place: "بوشهر",
		img: "/images/workshop.jpg",
		tag: "ساخت و اجرا"
	}
];
var buttonVariants = cva("inline-flex items-center justify-center gap-2 rounded-md text-[15px] font-medium transition-[transform,background-color,color,border-color,box-shadow] duration-150 ease-out active:not-disabled:scale-[0.96] disabled:opacity-50", {
	variants: {
		variant: {
			amber: "bg-amber text-navy hover:brightness-105 shadow-[0_0_0_1px_rgba(242,169,0,0.2),0_0_24px_rgba(242,169,0,0.18)]",
			ghost: "border border-cream/30 bg-transparent text-cream hover:border-teal/60 hover:text-teal-soft",
			navy: "bg-navy text-cream hover:bg-navy-mid",
			outline: "border border-navy/15 bg-transparent text-navy hover:border-teal hover:text-teal",
			teal: "bg-teal text-navy-deep hover:brightness-110"
		},
		size: {
			md: "h-12 min-h-11 px-6",
			lg: "h-14 min-h-11 px-8 text-base",
			sm: "h-11 min-h-11 px-4 text-sm"
		}
	},
	defaultVariants: {
		variant: "amber",
		size: "md"
	}
});
function Button({ className, variant, size, href, children, ...props }) {
	const cls = cn(buttonVariants({
		variant,
		size
	}), className);
	if (href) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: href,
		className: cls,
		children
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		className: cls,
		...props,
		children
	});
}
var VOLUME = .15;
function AmbientAudio() {
	const ref = (0, import_react.useRef)(null);
	const [on, setOn] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const a = ref.current;
		if (!a) return;
		a.volume = VOLUME;
		a.loop = true;
		const tryPlay = () => {
			a.volume = VOLUME;
			a.play().then(() => setOn(true)).catch(() => setOn(false));
		};
		tryPlay();
		const start = () => tryPlay();
		window.addEventListener("pointerdown", start, { once: true });
		return () => window.removeEventListener("pointerdown", start);
	}, []);
	function toggle() {
		const a = ref.current;
		if (!a) return;
		if (on) {
			a.pause();
			setOn(false);
		} else {
			a.volume = VOLUME;
			a.play().then(() => setOn(true)).catch(() => setOn(false));
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("audio", {
		ref,
		src: "/audio/background.m4a",
		loop: true,
		preload: "auto"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: toggle,
		className: "fixed bottom-5 left-5 z-[60] inline-flex h-11 min-w-11 items-center gap-2 rounded-md border border-white/10 bg-navy/90 px-3 text-[12px] text-cream backdrop-blur-sm",
		"aria-pressed": on,
		"aria-label": on ? "خاموش کردن صدا" : "روشن کردن صدا",
		children: [on ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "hidden sm:inline",
			children: on ? "صدا روشن" : "صدا خاموش"
		})]
	})] });
}
function Logo({ compact = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/",
		className: "group flex shrink-0 items-center gap-2.5",
		"aria-label": COMPANY,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "relative grid size-11 shrink-0 place-items-center overflow-hidden rounded-md bg-white md:size-12",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/images/logo.png",
				alt: "",
				className: "size-full object-contain p-0.5 outline-none"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: cn("leading-tight text-cream", compact && "hidden sm:block"),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block max-w-[11rem] text-[12px] font-semibold tracking-tight md:max-w-none md:text-[13px]",
				children: COMPANY
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "latin mt-0.5 block text-[10px] tracking-[0.14em] uppercase opacity-70",
				children: "NAVVAB"
			})]
		})]
	});
}
function Footer() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "relative overflow-hidden bg-navy text-cream",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "glow-orb -left-24 -top-24 size-[420px] glow-breathe" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto grid max-w-7xl gap-12 px-5 py-16 lg:grid-cols-12 lg:px-8 lg:py-20",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, { light: true }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 max-w-sm text-[15px] leading-[1.85] text-cream/70",
							children: MANIFESTO
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 max-w-sm text-[14px] leading-[1.85] text-cream/75",
							children: ADDRESS
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-[13px] text-cream/50",
							children: ["کد پستی: ", POSTAL]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "latin mt-6 text-xs tracking-[0.18em] text-teal-soft",
							children: "INDUSTRY · ENGINEERING · TECHNOLOGY"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-10 sm:grid-cols-3 lg:col-span-7",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-widest text-cream/45",
							children: "سایت"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-4 space-y-2.5",
							children: NAV.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: n.href,
								className: "text-[14px] text-cream/80 hover:text-teal-soft",
								children: n.label
							}) }, n.href))
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-widest text-cream/45",
							children: "توانمندی‌ها"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-4 space-y-2.5",
							children: SERVICES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: s.href,
								className: "text-[14px] text-cream/80 hover:text-teal-soft",
								children: s.title
							}) }, s.title))
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-widest text-cream/45",
							children: "ارتباط"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "mt-4 space-y-2.5 text-[14px] text-cream/80",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/contact",
									className: "hover:text-teal-soft",
									children: "تماس با ما"
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/navvab",
									className: "hover:text-teal-soft",
									children: "دستگاه وکیوم شارژ مولکولارسیو"
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/rd",
									className: "hover:text-teal-soft",
									children: "ثبت ایده"
								}) })
							]
						})] })
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative border-t border-white/8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-7xl flex-col gap-3 px-5 py-6 text-[13px] text-cream/45 lg:flex-row lg:items-center lg:justify-between lg:px-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: COMPANY }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "از تجربه عملیاتی تا راهکار مهندسی" })]
				})
			})
		]
	});
}
function Header() {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const [scrolled, setScrolled] = (0, import_react.useState)(false);
	const isHome = pathname === "/";
	(0, import_react.useEffect)(() => {
		const onScroll = () => setScrolled(window.scrollY > 24);
		onScroll();
		window.addEventListener("scroll", onScroll, { passive: true });
		return () => window.removeEventListener("scroll", onScroll);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: cn("fixed inset-x-0 top-0 z-50 transition-[background-color,border-color,backdrop-filter] duration-300", scrolled || !isHome ? "border-b border-white/8 bg-navy/94 backdrop-blur-md" : "border-b border-white/8 bg-navy/72 backdrop-blur-sm"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-7xl flex-col gap-1 px-3 py-2.5 md:px-6 lg:flex-row lg:items-center lg:justify-between lg:gap-4 lg:px-8 lg:py-0 lg:h-[72px]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, { compact: true }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/contact",
						className: "inline-flex h-9 shrink-0 items-center rounded-md bg-amber px-3 text-[12px] font-medium text-navy transition-transform duration-150 active:scale-[0.96] lg:hidden",
						children: "ارتباط با ما"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "flex flex-wrap items-center gap-x-1 gap-y-1 lg:flex-nowrap lg:gap-1",
					"aria-label": "اصلی",
					children: NAV.map((item) => {
						const active = pathname === item.href;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: item.href,
							className: cn("rounded-md px-2 py-1.5 text-[12px] whitespace-nowrap transition-colors duration-150 md:px-2.5 md:text-[13px]", active ? "bg-white/8 text-teal-soft" : "text-cream/82 hover:text-cream"),
							children: item.label
						}, item.href);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/contact",
					className: "hidden h-11 shrink-0 items-center rounded-md bg-amber px-4 text-[13px] font-medium text-navy transition-transform duration-150 active:scale-[0.96] lg:inline-flex",
					children: "ارتباط با ما"
				})
			]
		})
	});
}
function SiteShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh max-w-full overflow-x-clip bg-soft text-ink",
		dir: "rtl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AmbientAudio, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", { children }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
		]
	});
}
function PageHero({ kicker, title, lead }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative overflow-hidden bg-navy pt-36 pb-16 text-cream md:pt-40 md:pb-20",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "site-grid pointer-events-none absolute inset-0 opacity-70" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "glow-orb glow-breathe -right-16 top-10 size-[380px]" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "glow-orb bottom-0 left-10 size-[240px] opacity-50" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto max-w-7xl px-5 lg:px-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-[0.22em] text-teal-soft",
						children: kicker
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-4 h-px w-16 bg-teal glow-line" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "ambient-halo mt-6 max-w-4xl text-[40px] font-semibold leading-[1.25] md:text-[56px]",
						children: title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 max-w-2xl text-[16px] leading-[1.85] text-cream/72",
						children: lead
					})
				]
			})
		]
	});
}
//#endregion
export { FLOW as a, POSTAL as c, PageHero as d, Reveal as f, cn as g, WHY as h, COMPANY as i, PROCESS as l, TAGLINE as m, BUILD_CARDS as n, MANIFESTO as o, SiteShell as p, Button as r, PATH_STEPS as s, ADDRESS as t, PROJECTS as u };
