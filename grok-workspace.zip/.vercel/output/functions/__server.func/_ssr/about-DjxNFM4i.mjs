import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as PageHero, f as Reveal, h as WHY, p as SiteShell, s as PATH_STEPS } from "./SiteShell-C2EYCLcb.mjs";
import { n as FinalCta } from "./HomePage-DgBZPfQZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-DjxNFM4i.js
var import_jsx_runtime = require_jsx_runtime();
function AboutPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
			kicker: "درباره ما",
			title: "تجربه‌ای شکل‌گرفته در دل صنعت",
			lead: "کاوشگران فنون توسعه نفت در سال ۱۳۹۶ فعالیت خود را آغاز کرد؛ اما سابقه و تجربه شکل‌دهنده این مجموعه به بیش از دو دهه فعالیت عملی در صنعت بازمی‌گردد."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-soft py-20 md:py-28",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-7xl gap-12 px-5 lg:grid-cols-12 lg:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
					className: "space-y-5 text-[16px] leading-[1.9] text-ink/80 lg:col-span-7 md:text-[17px]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "در طول این سال‌ها، حضور در پروژه‌های مختلف نفت، گاز و پتروشیمی، ما را با طیف گسترده‌ای از فعالیت‌های اجرایی و فنی آشنا کرده است؛ از تعمیرات و نگهداری تجهیزات و تعمیرات اساسی واحدها گرفته تا نصب و راه‌اندازی، ساخت قطعات خاص و طراحی ابزارآلات مورد نیاز عملیات." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[20px] font-medium text-navy",
							children: "مسئله واقعی صنعت را باید از نزدیک شناخت تا بتوان برای آن راهکار واقعی ساخت."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "به همین دلیل، فعالیت ما تنها به اجرای خدمات محدود نمانده و مسیر پژوهش، توسعه و ساخت تجهیزات تخصصی نیز در مجموعه شکل گرفته است." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "هدف، جایگزین کردن تجربه با فناوری نیست؛ هدف، تبدیل تجربه به فناوری است. هویت اصلی شرکت در یک جمله خلاصه می‌شود: تجربه صنعت، توسعه فناوری." })
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: 100,
					className: "lg:col-span-5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/images/workshop.jpg",
						alt: "کارگاه مهندسی و ساخت",
						className: "aspect-[4/5] w-full rounded-xl object-cover"
					})
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-cream py-20 md:py-28",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-5 lg:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-[0.2em] text-teal",
					children: "مسیر توسعه"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-[32px] font-semibold text-navy md:text-[44px]",
					children: "از مسئله تا اجرای صنعتی"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-4",
					children: PATH_STEPS.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
						delay: i * 50,
						as: "li",
						className: "rounded-xl bg-soft p-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "latin text-teal",
							children: String(i + 1).padStart(2, "0")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-[20px] font-medium text-navy",
							children: s
						})]
					}, s))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-soft py-20 md:py-28",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-5 lg:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-[32px] font-semibold text-navy md:text-[44px]",
					children: "چرا این مجموعه؟"
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-12 grid gap-10 md:grid-cols-2 lg:grid-cols-3",
					children: WHY.map((w, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
						delay: i * 60,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-[22px] font-medium text-navy",
							children: w.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-[15px] leading-[1.85] text-ink/70",
							children: w.body
						})]
					}, w.title))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FinalCta, {})
	] });
}
//#endregion
export { AboutPage as component };
