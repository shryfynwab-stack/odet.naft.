import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as POSTAL, d as PageHero, f as Reveal, i as COMPANY, o as MANIFESTO, p as SiteShell, r as Button, t as ADDRESS } from "./SiteShell-C2EYCLcb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-Betec5jf.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ContactPage() {
	const [sent, setSent] = (0, import_react.useState)(false);
	function onSubmit(e) {
		e.preventDefault();
		const form = e.currentTarget;
		const data = Object.fromEntries(new FormData(form).entries());
		const prev = JSON.parse(localStorage.getItem("kavosh-inquiries") || "[]");
		prev.push({
			...data,
			at: (/* @__PURE__ */ new Date()).toISOString()
		});
		localStorage.setItem("kavosh-inquiries", JSON.stringify(prev));
		setSent(true);
		form.reset();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteShell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
		kicker: "تماس با ما",
		title: "یک مسئله صنعتی دارید؟",
		lead: "شاید نقطه شروع فناوری بعدی ما باشد. مسئله را با ما در میان بگذارید؛ به دنبال شناخت شرایط و پیدا کردن راهکار قابل اجرا هستیم."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-soft py-16 md:py-24",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-7xl gap-12 px-5 lg:grid-cols-12 lg:px-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				className: "lg:col-span-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-[28px] font-semibold text-navy",
						children: COMPANY
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-[16px] leading-[1.9] text-ink/75",
						children: MANIFESTO
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 space-y-2 text-[15px] leading-[1.85] text-ink/80",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium text-navy",
								children: "نشانی"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: ADDRESS }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["کد پستی: ", POSTAL] })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-8 text-[15px] leading-[1.85] text-ink/70",
						children: "اگر در فرآیندهای اجرایی، تجهیزات یا فعالیت‌های فنی خود با یک مسئله مشخص مواجه هستید، فرم مقابل را تکمیل کنید."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/images/piping.jpg",
						alt: "",
						className: "mt-10 aspect-[16/10] w-full rounded-xl object-cover"
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				delay: 80,
				className: "lg:col-span-7",
				children: sent ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl bg-cream p-8 md:p-10",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[22px] font-medium text-navy",
							children: "پیام شما ثبت شد."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-[15px] leading-[1.85] text-ink/70",
							children: "در اولین فرصت با شما تماس می‌گیریم. اگر موضوع فوریت دارد، می‌توانید دوباره از همین صفحه پیام دیگری ارسال کنید."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "mt-6 text-[14px] text-teal",
							onClick: () => setSent(false),
							children: "ارسال پیام دیگر"
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit,
					className: "rounded-xl bg-cream p-6 shadow-[var(--shadow-card)] md:p-10",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-5 md:grid-cols-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									name: "name",
									label: "نام و نام خانوادگی",
									required: true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									name: "org",
									label: "سازمان / شرکت"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									name: "phone",
									label: "تلفن",
									type: "tel",
									required: true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									name: "email",
									label: "ایمیل",
									type: "email"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-5 block",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[13px] text-muted",
								children: "موضوع"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								name: "topic",
								className: "mt-1.5 h-12 w-full rounded-md border-0 bg-soft px-3 text-[15px] text-navy outline-none ring-1 ring-navy/10 focus:ring-2 focus:ring-teal",
								defaultValue: "مشاوره فنی",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "مشاوره فنی" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "خدمات اجرایی" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "محصولات Navvab" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "ثبت ایده" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "سایر" })
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-5 block",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[13px] text-muted",
								children: "شرح مسئله"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								name: "message",
								required: true,
								rows: 6,
								className: "mt-1.5 w-full rounded-md border-0 bg-soft px-3 py-3 text-[15px] leading-[1.8] text-navy outline-none ring-1 ring-navy/10 focus:ring-2 focus:ring-teal"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-6",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								variant: "amber",
								size: "lg",
								children: "ارسال درخواست"
							})
						})
					]
				})
			})]
		})
	})] });
}
function Field({ name, label, type = "text", required }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-[13px] text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			name,
			type,
			required,
			className: "mt-1.5 h-12 w-full rounded-md border-0 bg-soft px-3 text-[15px] text-navy outline-none ring-1 ring-navy/10 focus:ring-2 focus:ring-teal"
		})]
	});
}
//#endregion
export { ContactPage as component };
