import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as PageHero, f as Reveal, p as SiteShell } from "./SiteShell-C2EYCLcb.mjs";
import { n as FinalCta } from "./HomePage-DgBZPfQZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/knowledge-DMcY-1Yi.js
var import_jsx_runtime = require_jsx_runtime();
function KnowledgePage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
			kicker: "دانش و تجربه",
			title: "فناوری زمانی ارزشمند است که یک مسئله واقعی را حل کند",
			lead: "ما فناوری را جدا از صنعت تعریف نمی‌کنیم. هر راهکار باید از یک نیاز واقعی شروع شود و در محیط صنعتی قابل استفاده باشد."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-soft py-20 md:py-28",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-7xl gap-16 px-5 lg:grid-cols-12 lg:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
					className: "lg:col-span-7 space-y-6 text-[16px] leading-[1.9] text-ink/80",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "برای ما، مسیر توسعه یک محصول با طراحی روی کاغذ تمام نمی‌شود. طراحی، ساخت، آزمون و آماده‌سازی برای اجرای صنعتی، بخش‌های یک مسیر واحد هستند." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "دستگاه وکیوم شارژ مولکولارسیو، نقطه‌ای از مسیر توسعه محصولات تخصصی کاوشگران فنون توسعه نفت است. تجربه‌های به‌دست‌آمده از این مسیر، زمینه‌ای برای شناسایی و توسعه راهکارهای بعدی فراهم می‌کند." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "هدف، توسعه تجهیزاتی است که بتوانند در بخش‌های مختلف صنعت نفت، گاز و پتروشیمی، پاسخگوی نیازهای مشخص عملیاتی باشند." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[22px] font-medium text-navy",
							children: "توسعه ادامه دارد."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: 80,
					className: "lg:col-span-5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/images/catalyst.jpg",
						alt: "مواد مولکولارسیو",
						className: "w-full rounded-xl object-cover"
					})
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-cream py-20",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-5 lg:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-[32px] font-semibold text-navy",
					children: "اصول نگاه ما"
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10 grid gap-8 md:grid-cols-3",
					children: [
						{
							t: "شروع از مسئله",
							b: "راهکار از نیاز واقعی عملیات آغاز می‌شود، نه از ایده انتزاعی."
						},
						{
							t: "ساخت قابل آزمون",
							b: "ایده زمانی ارزشمند است که به تجهیز قابل استفاده تبدیل شود."
						},
						{
							t: "آمادگی برای صنعت",
							b: "نتیجه باید در شرایط واقعی سایت، زمان و نیروی انسانی معنا داشته باشد."
						}
					].map((x, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
						delay: i * 70,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "latin text-teal",
								children: String(i + 1).padStart(2, "0")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-3 text-[22px] font-medium text-navy",
								children: x.t
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-[15px] leading-[1.85] text-ink/70",
								children: x.b
							})
						]
					}, x.t))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FinalCta, {})
	] });
}
//#endregion
export { KnowledgePage as component };
