import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as PageHero, f as Reveal, p as SiteShell, r as Button } from "./SiteShell-C2EYCLcb.mjs";
import { n as FinalCta } from "./HomePage-DgBZPfQZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/maintenance-O3qSXWVB.js
var import_jsx_runtime = require_jsx_runtime();
var AREAS = [
	"تعمیرات و نگهداری تجهیزات صنعتی",
	"اورهال واحدها و تجهیزات",
	"نصب و راه‌اندازی",
	"عیب‌یابی و رفع مشکلات عملیاتی",
	"اجرای فعالیت‌های تخصصی در سایت‌های صنعتی"
];
function MaintenancePage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
			kicker: "تعمیرات و نگهداری",
			title: "تجربه‌ای که از میدان عملیات می‌آید",
			lead: "بخش مهمی از تجربه کاوشگران فنون توسعه نفت در حوزه تعمیرات، نگهداری و فعالیت‌های تخصصی تجهیزات صنایع نفت، گاز و پتروشیمی شکل گرفته است."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-soft py-20 md:py-28",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-7xl items-center gap-12 px-5 lg:grid-cols-12 lg:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
					className: "lg:col-span-7 space-y-5 text-[16px] leading-[1.9] text-ink/80",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "از تعمیرات جاری تا اورهال، شناخت شرایط واقعی تجهیزات، محدودیت‌های عملیاتی و اهمیت زمان در پروژه‌های صنعتی، بخشی از تجربه عملیاتی ماست." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[20px] font-medium text-navy",
							children: "حوزه‌های فعالیت"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "space-y-2",
							children: AREAS.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-2 size-1.5 shrink-0 rounded-full bg-teal" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: a })]
							}, a))
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: 80,
					className: "lg:col-span-5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/images/piping.jpg",
						alt: "تجهیزات صنعتی",
						className: "w-full rounded-xl object-cover"
					})
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-cream py-20 md:py-28",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto max-w-7xl px-5 lg:px-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
					className: "max-w-3xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-[0.2em] text-teal",
							children: "رویکرد ما"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-4 text-[32px] font-semibold text-navy md:text-[44px]",
							children: "تجربه، ابزار شناخت مسئله است"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 text-[16px] leading-[1.9] text-ink/80",
							children: "تجربه برای ما صرفاً سابقه کاری نیست؛ ابزاری است برای شناخت دقیق‌تر مسئله و رسیدن به راهکاری که در شرایط واقعی صنعت قابل اجرا باشد."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 text-[16px] leading-[1.9] text-ink/80",
							children: "شناخت تجهیزات، درک شرایط عملیاتی و تجربه حضور در پروژه‌های صنعتی، به ما کمک می‌کند فعالیت‌های تعمیراتی را با نگاه دقیق‌تر به زمان، کیفیت و الزامات اجرایی دنبال کنیم."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-10",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								href: "/contact",
								variant: "navy",
								children: "مشاهده خدمات تعمیرات و نگهداری"
							})
						})
					]
				})
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FinalCta, {})
	] });
}
//#endregion
export { MaintenancePage as component };
