import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as FLOW, d as PageHero, f as Reveal, l as PROCESS, p as SiteShell, r as Button } from "./SiteShell-C2EYCLcb.mjs";
import { n as FinalCta } from "./HomePage-DgBZPfQZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/navvab-ocIbIPwO.js
var import_jsx_runtime = require_jsx_runtime();
var CHALLENGES = [
	"زمان طولانی عملیات",
	"نیاز به نیروی انسانی بیشتر",
	"انتقال مواد به ارتفاع رآکتور",
	"دشواری مدیریت عملیات در رآکتورهای متعدد",
	"اشغال فضای عملیاتی برای مدت طولانی‌تر",
	"وابستگی بیشتر فرآیند به عملیات دستی"
];
var FEATURES = [
	"عملکرد کاملاً پنوماتیک",
	"عدم نیاز به برق برای عملکرد دستگاه",
	"قابلیت استفاده در محیط‌های صنعتی مستعد خطر",
	"انتقال مواد از سطح زمین به ارتفاع رآکتور",
	"طراحی متناسب با عملیات صنعتی",
	"کاهش وابستگی به حمل و انتقال دستی مواد",
	"امکان استفاده برای شارژ مواد مختلف متناسب با فرآیند"
];
function NavvabPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
			kicker: "NAVVAB",
			title: "وقتی تجربه صنعتی، به یک تجهیز واقعی تبدیل می‌شود",
			lead: "Navvab / نواب برند محصولات و تجهیزات تخصصی توسعه‌یافته توسط کاوشگران فنون توسعه نفت است؛ محصولاتی که از دل نیازهای واقعی صنعت شکل می‌گیرند."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-soft py-20 md:py-28",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-7xl items-center gap-12 px-5 lg:grid-cols-2 lg:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-[0.2em] text-teal",
						children: "محصول شاخص"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-4 text-[32px] font-semibold leading-[1.3] text-navy md:text-[44px]",
						children: "دستگاه وکیوم شارژ مولکولارسیو"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 text-[18px] font-medium text-blue",
						children: "فناوری نوین برای کاهش زمان عملیات شارژ و بازگشت سریع‌تر رآکتورها به مدار"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 space-y-4 text-[16px] leading-[1.9] text-ink/78",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "شارژ مولکولارسیو، کاتالیست و مواد مشابه در رآکتورهای صنایع نفت، گاز و پتروشیمی، به‌ویژه در زمان توقف واحد، یکی از فعالیت‌هایی است که می‌تواند به زمان و نیروی انسانی قابل توجهی نیاز داشته باشد." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "در روش‌های متداول، انتقال مواد به ارتفاع رآکتور و شارژ آن‌ها به‌صورت دستی انجام می‌شود. دستگاه وکیوم شارژ مولکولارسیو با استفاده از سیستم مکش پنوماتیک، روشی متفاوت برای انتقال مواد از سطح زمین به داخل رآکتور ارائه می‌کند." })]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
					delay: 80,
					className: "relative",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "glow-orb -left-6 top-8 size-52" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/images/product-device.jpg",
						alt: "دستگاه وکیوم شارژ مولکولارسیو",
						className: "relative aspect-[4/3] w-full rounded-xl object-cover"
					})]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-cream py-20 md:py-28",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-5 lg:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-[0.2em] text-teal",
						children: "مسئله چیست؟"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-4 max-w-3xl text-[32px] font-semibold text-navy md:text-[44px]",
						children: "وقتی زمان، بخشی از هزینه عملیات است"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 max-w-2xl text-[16px] leading-[1.9] text-ink/80",
						children: "در روش سنتی، عملیات شارژ معمولاً با نیروی انسانی زیاد و در مدت زمان طولانی انجام می‌شود. در شرایطی که چند رآکتور باید در یک بازه زمانی مشخص شارژ شوند، طولانی شدن این عملیات می‌تواند زمان بازگشت تجهیزات به مدار را افزایش دهد."
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
					children: CHALLENGES.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
						delay: i * 50,
						className: "rounded-xl bg-soft p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "latin text-[12px] text-teal",
							children: String(i + 1).padStart(2, "0")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-[16px] font-medium text-navy",
							children: c
						})]
					}, c))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative overflow-hidden bg-navy py-20 text-cream md:py-28",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "glow-orb glow-breathe right-0 top-0 size-[420px]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative mx-auto max-w-7xl px-5 lg:px-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-[0.2em] text-teal-soft",
						children: "راهکار Navvab"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "ambient-halo mt-4 text-[32px] font-semibold md:text-[44px]",
						children: "انتقال مواد با سیستم مکش پنوماتیک"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 max-w-2xl text-[16px] leading-[1.9] text-cream/75",
						children: "دستگاه در قسمت بالایی رآکتور نصب می‌شود و با ایجاد مکش قدرتمند، مواد را از ظروف سطح زمین دریافت کرده و به بخش بالایی رآکتور منتقل می‌کند. این طراحی با هدف ساده‌سازی عملیات، کاهش زمان شارژ و کاهش نیاز به نیروی انسانی توسعه یافته است."
					})
				] })
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-soft py-20 md:py-28",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-5 lg:px-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-[32px] font-semibold text-navy md:text-[44px]",
						children: "دستگاه چگونه کار می‌کند؟"
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "mt-10 grid gap-4 md:grid-cols-3",
						children: FLOW.map((f, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
							delay: i * 40,
							as: "li",
							className: "rounded-xl bg-cream p-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "latin text-teal",
								children: String(i + 1).padStart(2, "0")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-[17px] font-medium text-navy",
								children: f
							})]
						}, f))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-10 grid gap-5 md:grid-cols-2",
						children: PROCESS.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
							delay: i * 40,
							className: "rounded-xl bg-cream p-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
								className: "text-[20px] font-medium text-navy",
								children: [
									p.n,
									" — ",
									p.title
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-[15px] leading-[1.85] text-ink/70",
								children: p.body
							})]
						}, p.n))
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-cream py-20 md:py-28",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-5 lg:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-[32px] font-semibold text-navy md:text-[44px]",
					children: "طراحی‌شده برای شرایط واقعی صنعت"
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-10 grid gap-3 md:grid-cols-2",
					children: FEATURES.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex gap-3 text-[15px] leading-[1.8] text-ink/80",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-2 size-1.5 shrink-0 rounded-full bg-teal" }), f]
					}, f))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-navy py-20 text-cream md:py-28",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-5 lg:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "ambient-halo text-[32px] font-semibold md:text-[44px]",
					children: "نتایج آزمون و عملکرد"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-5 max-w-2xl text-[16px] leading-[1.9] text-cream/70",
					children: "در آزمون‌های نهایی انجام‌شده، این تجهیز توانسته است زمان و نیروی انسانی موردنیاز برای عملیات شارژ را به شکل قابل توجهی کاهش دهد."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-12 grid gap-8 sm:grid-cols-3",
					children: [
						{
							k: "زمان عملیات",
							a: "۱۸ تا ۲۴ ساعت",
							b: "حدود ۴ ساعت"
						},
						{
							k: "نیروی انسانی",
							a: "حدود ۲۵ نفر",
							b: "حدود ۳ نفر"
						},
						{
							k: "چند رآکتور",
							a: "مرحله‌ای",
							b: "تا سه رآکتور"
						}
					].map((x, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
						delay: i * 80,
						className: "rounded-xl border border-white/8 p-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[13px] text-cream/50",
								children: x.k
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 text-[15px] text-cream/45 line-through",
								children: x.a
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-[28px] font-semibold text-teal-soft",
								children: x.b
							})
						]
					}, x.k))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-soft py-20 md:py-28",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-5 lg:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-[32px] font-semibold text-navy md:text-[48px]",
					children: "زمان کمتر، بازگشت سریع‌تر به مدار"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 max-w-2xl text-[16px] leading-[1.9] text-ink/80",
					children: "ارزش این تجهیز تنها در سرعت بالاتر انتقال مواد خلاصه نمی‌شود. کاهش زمان عملیات شارژ می‌تواند به معنای زمان کمتر برای شارژ، کاهش زمان خارج بودن رآکتور از سرویس، آزاد شدن سریع‌تر فضای عملیاتی و آمادگی سریع‌تر برای ادامه فرآیند راه‌اندازی باشد."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-14 grid gap-8 md:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
						className: "rounded-xl bg-cream p-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-[22px] font-medium text-navy",
								children: "خرید دستگاه"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 text-[15px] leading-[1.85] text-ink/75",
								children: "مجموعه‌های فعال در صنایع نفت، گاز و پتروشیمی می‌توانند دستگاه را به‌عنوان یک تجهیز تخصصی برای عملیات خود تهیه کنند."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-6",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									href: "/contact",
									variant: "navy",
									children: "درخواست اطلاعات فنی دستگاه"
								})
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
						delay: 80,
						className: "rounded-xl bg-cream p-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-[22px] font-medium text-navy",
								children: "اجرای عملیات توسط کاوشگران"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 text-[15px] leading-[1.85] text-ink/75",
								children: "علاوه بر ارائه تجهیز، آمادگی داریم عملیات شارژ رآکتورها را با استفاده از دستگاه و تحت برند Navvab در مجموعه‌های صنعتی اجرا کنیم."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-6",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									href: "/contact",
									variant: "outline",
									children: "درخواست اجرای عملیات"
								})
							})
						]
					})]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-cream py-16",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-7xl gap-6 px-5 md:grid-cols-3 lg:px-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/images/product-device.jpg",
						alt: "نمای دستگاه",
						className: "aspect-[4/3] w-full rounded-xl object-cover"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/images/reactor.jpg",
						alt: "محل نصب",
						className: "aspect-[4/3] w-full rounded-xl object-cover"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/images/catalyst-bags.jpg",
						alt: "مسیر انتقال مواد",
						className: "aspect-[4/3] w-full rounded-xl object-cover"
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FinalCta, {})
	] });
}
//#endregion
export { NavvabPage as component };
