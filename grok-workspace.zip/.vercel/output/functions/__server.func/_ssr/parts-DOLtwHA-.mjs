import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as PageHero, f as Reveal, p as SiteShell, r as Button } from "./SiteShell-C2EYCLcb.mjs";
import { n as FinalCta } from "./HomePage-DgBZPfQZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/parts-DOLtwHA-.js
var import_jsx_runtime = require_jsx_runtime();
var AREAS = [
	"ساخت قطعات تخصصی",
	"ساخت قطعات موردنیاز اورهال",
	"مهندسی معکوس قطعات و تجهیزات",
	"طراحی و ساخت ابزارآلات صنعتی",
	"ساخت تجهیزات متناسب با نیاز پروژه",
	"بازطراحی و توسعه قطعات",
	"ساخت نمونه‌های خاص و کم‌یاب"
];
var PATH = [
	"نمونه موجود",
	"بررسی و اندازه‌برداری",
	"مهندسی معکوس",
	"طراحی و مدل‌سازی",
	"انتخاب مواد و فرآیند ساخت",
	"تولید",
	"کنترل و آزمون",
	"تحویل قطعه"
];
function PartsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
			kicker: "ساخت قطعات تخصصی",
			title: "وقتی یک قطعه، بخشی از راهکار است",
			lead: "در بسیاری از پروژه‌های صنعتی، یک قطعه خاص یا تجهیز موردنیاز ممکن است به‌سادگی در دسترس نباشد یا نمونه موجود، پاسخگوی شرایط عملیاتی نباشد."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-soft py-20 md:py-28",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-7xl gap-12 px-5 lg:grid-cols-12 lg:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
					className: "lg:col-span-7 space-y-5 text-[16px] leading-[1.9] text-ink/80",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "کاوشگران فنون توسعه نفت با تکیه بر تجربه میدانی، توان مهندسی و شناخت نیازهای صنعت، در زمینه مهندسی معکوس، طراحی و ساخت قطعات و تجهیزات تخصصی فعالیت می‌کند." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[20px] font-medium text-navy",
							children: "حوزه‌های فعالیت"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "space-y-2",
							children: AREAS.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-2 size-1.5 shrink-0 rounded-full bg-teal" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: a })]
							}, a))
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: 80,
					className: "lg:col-span-5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/images/workshop.jpg",
						alt: "کارگاه ساخت",
						className: "w-full rounded-xl object-cover"
					})
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-cream py-20 md:py-28",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-5 lg:px-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-[32px] font-semibold text-navy md:text-[44px]",
							children: "مهندسی معکوس؛ از نمونه موجود تا قطعه موردنیاز"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 max-w-3xl text-[16px] leading-[1.9] text-ink/80",
							children: "هر قطعه‌ای که در اختیار مجموعه یا مشتری باشد، می‌تواند مبنای بررسی و مهندسی معکوس قرار گیرد. با بررسی دقیق ابعاد، ساختار، جنس، عملکرد و الزامات موردنیاز، امکان بازطراحی و ساخت مجدد قطعه فراهم می‌شود."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 max-w-3xl text-[16px] leading-[1.9] text-ink/80",
							children: "این فرآیند به شرکت‌ها امکان می‌دهد قطعات موردنیاز خود را بر اساس سفارش و مشخصات موردنظر، به‌صورت اختصاصی دریافت کنند؛ حتی در مواردی که قطعه اصلی کمیاب، وارداتی یا دشوار برای تأمین باشد."
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
						className: "mt-14",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-[0.2em] text-teal",
							children: "مسیر ساخت"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
							className: "mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
							children: PATH.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "rounded-xl bg-soft p-5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "latin text-teal",
									children: String(i + 1).padStart(2, "0")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-[17px] font-medium text-navy",
									children: s
								})]
							}, s))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
						className: "mt-12 max-w-3xl",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[16px] leading-[1.9] text-ink/80",
							children: "فرآیند ساخت از شناخت دقیق قطعه و نیاز عملیاتی آغاز می‌شود؛ از بررسی نمونه و شرایط استفاده تا طراحی، ساخت، کنترل و آماده‌سازی برای استفاده در صنعت."
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								href: "/contact",
								variant: "navy",
								children: "مشاهده توانمندی ساخت"
							})
						})]
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FinalCta, {})
	] });
}
//#endregion
export { PartsPage as component };
