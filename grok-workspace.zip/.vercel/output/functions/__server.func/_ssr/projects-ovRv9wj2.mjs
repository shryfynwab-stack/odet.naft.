import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as PageHero, f as Reveal, p as SiteShell, u as PROJECTS } from "./SiteShell-C2EYCLcb.mjs";
import { n as FinalCta } from "./HomePage-DgBZPfQZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/projects-ovRv9wj2.js
var import_jsx_runtime = require_jsx_runtime();
function ProjectsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
			kicker: "پروژه‌ها و تجربیات",
			title: "تجربه‌ای که در نقاط مختلف صنعت شکل گرفته است",
			lead: "حضور در پالایشگاه‌ها، مجتمع‌های پتروشیمی و مناطق عملیاتی مختلف کشور؛ از ستاره خلیج فارس تا پارس جنوبی."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-soft py-16 md:py-24",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-5 lg:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-6 md:grid-cols-2",
					children: PROJECTS.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
						delay: i * 50,
						as: "article",
						className: "overflow-hidden rounded-xl bg-cream shadow-[var(--shadow-card)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: p.img,
							alt: p.name,
							className: "aspect-[16/9] w-full object-cover"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-6 md:p-8",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[12px] text-teal",
									children: p.tag
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-2 text-[24px] font-medium text-navy md:text-[28px]",
									children: p.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-[14px] text-muted",
									children: p.place
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 text-[15px] leading-[1.85] text-ink/70",
									children: "فعالیت‌های اجرایی و فنی در حوزه تعمیرات، نگهداری، نصب و ساخت تجهیزات متناسب با شرایط واقعی سایت و برنامه عملیاتی پروژه."
								})
							]
						})]
					}, p.name))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					className: "mt-12 max-w-2xl text-[16px] leading-[1.9] text-ink/75",
					children: "این فهرست نمونه‌ای از سوابق حضور در مجموعه‌های صنعتی کشور است. تجربه عملیاتی، مبنای شناخت مسئله و توسعه راهکارهای بعدی قرار گرفته است."
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FinalCta, {})
	] });
}
//#endregion
export { ProjectsPage as component };
