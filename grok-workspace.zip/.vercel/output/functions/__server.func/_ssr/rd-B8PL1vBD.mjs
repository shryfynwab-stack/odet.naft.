import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as PageHero, f as Reveal, p as SiteShell, r as Button } from "./SiteShell-C2EYCLcb.mjs";
import { n as FinalCta } from "./HomePage-DgBZPfQZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/rd-B8PL1vBD.js
var import_jsx_runtime = require_jsx_runtime();
var PATH = [
	"ایده",
	"بررسی و امکان‌سنجی",
	"پژوهش و توسعه",
	"طراحی",
	"ساخت نمونه",
	"آزمون و ارزیابی",
	"توسعه برای صنعت"
];
var AXES = [
	"پژوهش و توسعه راهکارهای صنعتی",
	"ایده‌پروری و بررسی ایده‌های نو",
	"شناسایی مسائل و نیازهای صنعتی",
	"امکان‌سنجی ایده‌ها و راهکارها",
	"توسعه روش‌های جدید",
	"طراحی و ساخت تجهیزات تخصصی",
	"ساخت و آزمون نمونه‌های اولیه",
	"ارزیابی عملکرد و آماده‌سازی برای استفاده صنعتی"
];
function RdPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
			kicker: "پژوهش و توسعه",
			title: "از یک ایده تا یک فناوری قابل استفاده",
			lead: "بخش مهمی از مسیر توسعه کاوشگران فنون توسعه نفت از مشاهده مسائل واقعی و تکرارشونده در عملیات صنعتی شکل گرفته است."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-soft py-20 md:py-28",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto max-w-7xl px-5 lg:px-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
					className: "max-w-3xl space-y-5 text-[16px] leading-[1.9] text-ink/80",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "ما باور داریم بسیاری از راهکارهای جدید، پیش از آنکه به یک فناوری تبدیل شوند، یک ایده هستند؛ ایده‌ای که ممکن است از دل تجربه یک متخصص، یک نیروی فنی، یک مجموعه صنعتی یا حتی فردی خارج از این حوزه شکل گرفته باشد." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "به همین دلیل، در کنار پژوهش و توسعه داخلی، از ایده‌پروری و بررسی ایده‌های جدید نیز استقبال می‌کنیم." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "اگر ایده‌ای دارید که فکر می‌کنید می‌تواند یک مسئله صنعتی را حل کند، یک فرآیند را بهبود دهد یا به یک تجهیز، ابزار یا فناوری جدید تبدیل شود، می‌توانید آن را با ما مطرح کنید." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "ما ایده را بررسی می‌کنیم، امکان‌سنجی آن را می‌سنجیم و در صورت وجود ظرفیت توسعه، مسیر تبدیل آن به یک راهکار قابل ساخت و قابل استفاده در صنعت را دنبال می‌کنیم." })
					]
				})
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-cream py-20 md:py-28",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-5 lg:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-[0.2em] text-teal",
					children: "مسیر ایده تا فناوری"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
					children: PATH.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-xl bg-soft p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "latin text-teal",
							children: String(i + 1).padStart(2, "0")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-[17px] font-medium text-navy",
							children: s
						})]
					}, s))
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
					className: "mt-16",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-[28px] font-semibold text-navy",
						children: "محورهای فعالیت"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-6 grid gap-3 md:grid-cols-2",
						children: AXES.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-3 text-[15px] leading-[1.8] text-ink/80",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-2 size-1.5 shrink-0 rounded-full bg-teal" }), a]
						}, a))
					})]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative overflow-hidden bg-navy py-20 text-cream md:py-28",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "glow-orb left-10 top-0 size-[380px]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative mx-auto max-w-7xl px-5 lg:px-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "ambient-halo text-[32px] font-semibold md:text-[44px]",
						children: "یک ایده می‌تواند شروع یک فناوری باشد"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 max-w-2xl text-[16px] leading-[1.9] text-cream/75",
						children: "لازم نیست یک ایده از ابتدا کامل باشد. ممکن است یک مشاهده، یک تجربه عملیاتی یا یک پیشنهاد ساده، نقطه شروع یک راهکار جدید باشد."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 max-w-2xl text-[18px] font-medium",
						children: "ایده‌ای دارید که می‌تواند به یک راهکار صنعتی تبدیل شود؟"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							href: "/contact",
							variant: "amber",
							size: "lg",
							children: "ثبت ایده و پیشنهاد"
						})
					})
				] })
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-soft py-20 md:py-28",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-7xl items-center gap-12 px-5 lg:grid-cols-2 lg:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-[0.2em] text-teal",
						children: "نمونه‌ای از مسیر توسعه"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-4 text-[28px] font-semibold text-navy md:text-[36px]",
						children: "دستگاه وکیوم شارژ مولکولارسیو"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 text-[16px] leading-[1.9] text-ink/80",
						children: "راهکاری که از یک مسئله واقعی در عملیات تعمیرات شکل گرفت و با طی مسیر پژوهش، طراحی، ساخت و آزمون، به یک تجهیز تخصصی برای کاهش زمان عملیات شارژ رآکتورها تبدیل شد."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 text-[16px] leading-[1.9] text-ink/80",
						children: "پژوهش و توسعه زمانی ارزشمند است که از یک مسئله، نیاز یا ایده آغاز شود و در نهایت به راهکاری برسد که بتواند در شرایط واقعی صنعت مورد استفاده قرار گیرد. از ایده تا صنعت."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							href: "/navvab",
							variant: "outline",
							children: "معرفی Navvab"
						})
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: 80,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/images/product-device.jpg",
						alt: "",
						className: "w-full rounded-xl object-cover"
					})
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FinalCta, {})
	] });
}
//#endregion
export { RdPage as component };
