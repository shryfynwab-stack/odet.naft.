import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { p as SiteShell } from "./SiteShell-C2EYCLcb.mjs";
import { r as HomePage } from "./HomePage-DgBZPfQZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Bw0lBC8e.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomePage, {}) });
}
//#endregion
export { Home as component };
