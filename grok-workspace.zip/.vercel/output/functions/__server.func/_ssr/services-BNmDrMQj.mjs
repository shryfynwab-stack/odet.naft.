import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as PageHero, p as SiteShell } from "./SiteShell-C2EYCLcb.mjs";
import { n as FinalCta, t as BuildCards } from "./HomePage-DgBZPfQZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/services-BNmDrMQj.js
var import_jsx_runtime = require_jsx_runtime();
function ServicesPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
			kicker: "خدمات",
			title: "توانمندی‌هایی که از تجربه اجرایی شکل گرفته‌اند",
			lead: "تعمیرات و نگهداری، ساخت قطعات تخصصی، پژوهش و توسعه، و تجهیزات برند Navvab — چهار مسیر از دل صنعت."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BuildCards, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FinalCta, {})
	] });
}
//#endregion
export { ServicesPage as component };
