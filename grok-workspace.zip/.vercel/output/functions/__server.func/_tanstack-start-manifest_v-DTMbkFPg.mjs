//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DTMbkFPg.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/contact",
			"/knowledge",
			"/maintenance",
			"/navvab",
			"/parts",
			"/projects",
			"/rd",
			"/services"
		],
		preloads: ["/assets/index-Ct2cLUbR.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Ct2cLUbR.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-DWtU4HM_.js",
			"/assets/SiteShell-BCkA2XXk.js",
			"/assets/HomePage-_4Nvo8jc.js"
		]
	},
	"/about": {
		filePath: "/workspace/src/routes/about.tsx",
		children: void 0,
		preloads: [
			"/assets/about-Dwly5fP1.js",
			"/assets/SiteShell-BCkA2XXk.js",
			"/assets/HomePage-_4Nvo8jc.js"
		]
	},
	"/contact": {
		filePath: "/workspace/src/routes/contact.tsx",
		children: void 0,
		preloads: ["/assets/contact-D1WkcFyd.js", "/assets/SiteShell-BCkA2XXk.js"]
	},
	"/knowledge": {
		filePath: "/workspace/src/routes/knowledge.tsx",
		children: void 0,
		preloads: [
			"/assets/knowledge-o0hezqnH.js",
			"/assets/SiteShell-BCkA2XXk.js",
			"/assets/HomePage-_4Nvo8jc.js"
		]
	},
	"/maintenance": {
		filePath: "/workspace/src/routes/maintenance.tsx",
		children: void 0,
		preloads: [
			"/assets/maintenance-BMTMDiBM.js",
			"/assets/SiteShell-BCkA2XXk.js",
			"/assets/HomePage-_4Nvo8jc.js"
		]
	},
	"/navvab": {
		filePath: "/workspace/src/routes/navvab.tsx",
		children: void 0,
		preloads: [
			"/assets/navvab-DaezyBZ8.js",
			"/assets/SiteShell-BCkA2XXk.js",
			"/assets/HomePage-_4Nvo8jc.js"
		]
	},
	"/parts": {
		filePath: "/workspace/src/routes/parts.tsx",
		children: void 0,
		preloads: [
			"/assets/parts-Dojk3nQy.js",
			"/assets/SiteShell-BCkA2XXk.js",
			"/assets/HomePage-_4Nvo8jc.js"
		]
	},
	"/projects": {
		filePath: "/workspace/src/routes/projects.tsx",
		children: void 0,
		preloads: [
			"/assets/projects-DSDQhCSr.js",
			"/assets/SiteShell-BCkA2XXk.js",
			"/assets/HomePage-_4Nvo8jc.js"
		]
	},
	"/rd": {
		filePath: "/workspace/src/routes/rd.tsx",
		children: void 0,
		preloads: [
			"/assets/rd-IMleFXo7.js",
			"/assets/SiteShell-BCkA2XXk.js",
			"/assets/HomePage-_4Nvo8jc.js"
		]
	},
	"/services": {
		filePath: "/workspace/src/routes/services.tsx",
		children: void 0,
		preloads: [
			"/assets/services-BbOE1q-Z.js",
			"/assets/SiteShell-BCkA2XXk.js",
			"/assets/HomePage-_4Nvo8jc.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
