import { Volume2, VolumeX } from "lucide-react";
import { useEffect, useState } from "react";
import { ambientIsOn, pauseAmbient, playAmbient } from "@/lib/audio-engine";
import { useI18n } from "@/lib/i18n";

export function AmbientAudio() {
  const { t } = useI18n();
  const [on, setOn] = useState(false);

  useEffect(() => {
    if (sessionStorage.getItem("kavosh-audio") === "off") return;

    let timer = 0;
    let idle = 0;
    let armed = false;
    const start = () => {
      if (!armed) return;
      window.clearTimeout(timer);
      playAmbient().then(setOn);
    };
    const arm = () => {
      armed = true;
      const kick = () => {
        timer = window.setTimeout(start, 8000);
      };
      if ("requestIdleCallback" in window) {
        idle = window.requestIdleCallback(kick, { timeout: 12000 });
      } else {
        kick();
      }
    };

    if (document.readyState === "complete") arm();
    else window.addEventListener("load", arm, { once: true });

    const onPointer = () => {
      if (!armed || performance.now() < 4500) return;
      window.removeEventListener("pointerdown", onPointer);
      start();
    };
    window.addEventListener("pointerdown", onPointer);
    return () => {
      window.clearTimeout(timer);
      if (idle && "cancelIdleCallback" in window) window.cancelIdleCallback(idle);
      window.removeEventListener("load", arm);
      window.removeEventListener("pointerdown", onPointer);
    };
  }, []);

  function toggle() {
    if (on || ambientIsOn()) {
      pauseAmbient();
      setOn(false);
    } else {
      playAmbient().then(setOn);
    }
  }

  return (
    <button
      type="button"
      onClick={toggle}
      className="fixed bottom-5 z-[60] inline-flex h-11 min-w-11 items-center gap-2 rounded-md border border-white/10 bg-navy/90 px-3 text-[12px] text-cream backdrop-blur-sm start-5"
      aria-pressed={on}
      aria-label={on ? t.soundOn : t.soundOff}
    >
      {on ? <Volume2 className="size-4" /> : <VolumeX className="size-4" />}
      <span className="hidden sm:inline">{on ? t.soundOn : t.soundOff}</span>
    </button>
  );
}
