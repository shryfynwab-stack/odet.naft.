import { Link } from "@tanstack/react-router";
import { cn } from "@/lib/cn";
import { useI18n } from "@/lib/i18n";

export function Logo({ compact = false }: { light?: boolean; compact?: boolean }) {
  const { t } = useI18n();
  return (
    <Link to="/" viewTransition className="group flex shrink-0 items-center gap-2.5" aria-label={t.company}>
      <span className="relative grid size-11 shrink-0 place-items-center md:size-12">
        <span className="logo-halo" aria-hidden />
        <img
          src="/images/logo.webp"
          alt=""
          width={320}
          height={320}
          decoding="async"
          className="logo-glow relative z-[1] size-full object-contain"
        />
      </span>
      <span className={cn("leading-tight text-cream", compact && "hidden sm:block")}>
        <span className="block max-w-[12rem] text-[12px] font-semibold tracking-tight md:max-w-none md:text-[13px]">
          {t.company}
        </span>
        <span className="latin mt-0.5 block text-[10px] tracking-[0.14em] uppercase opacity-70">NAVVAB</span>
      </span>
    </Link>
  );
}
