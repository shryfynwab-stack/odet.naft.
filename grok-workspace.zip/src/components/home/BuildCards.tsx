import { Link } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight } from "lucide-react";
import { Reveal } from "@/components/motion/Reveal";
import { useI18n } from "@/lib/i18n";

const CARDS = [
  { href: "/navvab", img: "/images/reactor-1.webp", k: "n1k", t: "n1" },
  { href: "/maintenance", img: "/images/piping.webp", k: "n2k", t: "n2" },
  { href: "/parts", img: "/images/workshop.webp", k: "n3k", t: "n3" },
  { href: "/rd", img: "/images/column.webp", k: "n4k", t: "n4" },
] as const;

export function BuildCards() {
  const { t, lang } = useI18n();
  const Arrow = lang === "fa" ? ArrowLeft : ArrowRight;
  return (
    <section className="bg-navy py-20 text-cream md:py-28">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <Reveal>
          <p className="text-xs tracking-[0.2em] text-teal-soft">{t.cards.kicker}</p>
          <h2 className="ambient-halo mt-4 max-w-3xl text-[36px] font-semibold leading-[1.3] md:text-[52px]">
            {t.cards.title}
          </h2>
          <p className="mt-5 max-w-2xl text-[16px] leading-[1.9] text-cream/70">{t.cards.lead}</p>
        </Reveal>

        <div className="mt-12 grid gap-5 sm:grid-cols-2">
          {CARDS.map((card, i) => (
            <Reveal key={card.href} delay={i * 80}>
              <Link to={card.href as "/"} viewTransition className="group relative block aspect-[16/11] overflow-hidden rounded-xl">
                <img
                  src={card.img}
                  alt=""
                  loading="lazy"
                  decoding="async"
                  className="absolute inset-0 size-full object-cover transition-[transform,filter] duration-500 ease-out group-hover:scale-110 group-hover:brightness-[0.3] max-md:scale-105 max-md:brightness-[0.45]"
                />
                <div className="absolute inset-0 bg-navy/20 transition-colors duration-500 group-hover:bg-navy/55 max-md:bg-navy/40" />
                <div className="absolute inset-0 flex flex-col justify-end p-6 md:p-8">
                  <p className="latin text-[11px] tracking-[0.2em] text-teal-soft">{t.cards[card.k]}</p>
                  <h3 className="mt-2 text-[24px] font-semibold md:text-[28px]">{t.cards[card.t]}</h3>
                  <span className="mt-4 inline-flex h-11 w-fit items-center gap-2 rounded-md bg-cream px-4 text-[13px] font-medium text-navy opacity-100 transition-[opacity,transform] duration-500 ease-out md:translate-y-2 md:opacity-0 md:group-hover:translate-y-0 md:group-hover:opacity-100">
                    {t.more}
                    <Arrow className="size-4" />
                  </span>
                </div>
              </Link>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
