import { Reveal } from "@/components/motion/Reveal";
import { Button } from "@/components/ui/button";
import { useI18n } from "@/lib/i18n";

export function FinalCta() {
  const { t } = useI18n();
  return (
    <section className="relative overflow-hidden bg-navy py-24 text-cream md:py-32">
      <div className="glow-orb glow-breathe right-0 top-0 size-[480px]" />
      <div className="glow-orb-amber bottom-0 left-10 size-[180px]" />
      <div className="relative mx-auto max-w-7xl px-5 text-center lg:px-8">
        <Reveal>
          <h2 className="ambient-halo text-[40px] font-semibold md:text-[64px]">{t.cta.title}</h2>
          <p className="mx-auto mt-5 max-w-xl text-[18px] leading-[1.9] text-cream/72">{t.cta.lead}</p>
          <div className="mt-10 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Button href="/contact" variant="navy" size="lg" className="bg-cream text-navy hover:bg-cream/90">
              {t.contactCta}
            </Button>
            <Button href="/navvab" variant="ghost" size="lg">
              {t.cta.navvab}
            </Button>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
