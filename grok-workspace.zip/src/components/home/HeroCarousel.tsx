import { useEffect, useState } from "react";
import { useI18n } from "@/lib/i18n";

const SLIDES = [
  { img: "/images/hero.webp", sub: "sub1" as const, extra: false },
  { img: "/images/piping.webp", sub: "sub2" as const, extra: false },
  { img: "/images/workshop.webp", sub: "sub3" as const, extra: true },
];

export function HeroCarousel() {
  const { t } = useI18n();
  const [i, setI] = useState(0);
  const [rest, setRest] = useState(false);

  useEffect(() => {
    const id = window.setInterval(() => setI((n) => (n + 1) % SLIDES.length), 5000);
    const wait = window.setTimeout(() => setRest(true), 1200);
    return () => {
      window.clearInterval(id);
      window.clearTimeout(wait);
    };
  }, []);

  return (
    <section className="relative w-full overflow-hidden bg-navy pt-[108px] lg:pt-[72px]">
      <div className="relative aspect-[16/10] w-full md:aspect-[21/9]">
        {SLIDES.map((s, idx) => (
          <div
            key={s.img}
            className="absolute inset-0 transition-transform duration-700 ease-out"
            style={{ transform: `translateX(${(idx - i) * 100}%)` }}
          >
            <img
              src={idx === 0 || rest ? s.img : undefined}
              alt=""
              decoding="async"
              loading={idx === 0 ? "eager" : "lazy"}
              fetchPriority={idx === 0 ? "high" : "low"}
              className="size-full object-cover"
            />
            <div className="absolute inset-0 bg-navy/35" />
            <div className="absolute inset-0 flex flex-col items-center justify-center px-5 text-center">
              <p className="latin text-[13px] tracking-[0.28em] text-cream md:text-[16px]">NAVVAB</p>
              <h1 className="mt-3 max-w-4xl bg-cream/92 px-5 py-2 text-[22px] font-semibold leading-snug text-navy sm:text-[32px] md:text-[42px]">
                کاوشگران فنون توسعه نفت
              </h1>
              <p className="mt-4 text-[16px] font-medium text-cream drop-shadow md:text-[22px]">
                {t.carousel[s.sub]}
              </p>
              {s.extra ? (
                <p className="mt-1 text-[13px] text-cream/85 md:text-[16px]">{t.carousel.sub3b}</p>
              ) : null}
            </div>
          </div>
        ))}
      </div>
      <div className="absolute bottom-4 left-1/2 z-10 flex -translate-x-1/2 gap-2">
        {SLIDES.map((s, idx) => (
          <button
            key={s.img}
            type="button"
            aria-label={`slide ${idx + 1}`}
            onClick={() => setI(idx)}
            className={`h-1.5 rounded-full transition-all ${idx === i ? "w-8 bg-cream" : "w-3 bg-cream/40"}`}
          />
        ))}
      </div>
    </section>
  );
}
