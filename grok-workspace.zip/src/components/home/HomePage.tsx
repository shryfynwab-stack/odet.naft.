import { BuildCards } from "@/components/home/BuildCards";
import { FinalCta } from "@/components/home/FinalCta";
import { HeroCarousel } from "@/components/home/HeroCarousel";
import { CountUp } from "@/components/motion/CountUp";
import { Reveal } from "@/components/motion/Reveal";
import { useI18n } from "@/lib/i18n";

export function HomePage() {
  return (
    <>
      <HeroCarousel />
      <Stats />
      <BuildCards />
      <FinalCta />
    </>
  );
}

function Stats() {
  const { t, lang } = useI18n();
  const items = [
    { label: t.stats.yLabel, value: 20, prefix: "+", suffix: "" },
    { label: t.stats.startLabel, value: lang === "fa" ? 1396 : 2017, prefix: "", suffix: "" },
    { label: t.stats.fieldLabel, value: 0, custom: t.stats.field },
    { label: t.stats.productLabel, value: 1, prefix: "0", suffix: "" },
  ];
  return (
    <section className="relative overflow-hidden bg-navy-deep py-16 text-cream md:py-20">
      <div className="glow-orb right-1/4 top-0 size-[320px] opacity-50" />
      <div className="relative mx-auto grid max-w-7xl gap-8 px-5 sm:grid-cols-2 lg:grid-cols-4 lg:gap-6 lg:px-8">
        {items.map((item, i) => (
          <Reveal key={item.label} delay={i * 90} className="min-w-0">
            <p className="ambient-halo text-[40px] font-semibold leading-[1.15] text-cream md:text-[48px]">
              {item.custom ? (
                <span className="block text-[22px] leading-snug md:text-[26px]">{item.custom}</span>
              ) : (
                <CountUp key={`${item.label}-${item.value}`} to={item.value} prefix={item.prefix} suffix={item.suffix} />
              )}
            </p>
            <p className="mt-3 text-[13px] text-cream/55">{item.label}</p>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
