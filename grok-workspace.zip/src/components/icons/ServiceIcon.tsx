import type { ReactElement, SVGProps } from "react";

const icons: Record<string, (p: SVGProps<SVGSVGElement>) => ReactElement> = {
  wrench: (p) => (
    <svg viewBox="0 0 32 32" fill="none" stroke="currentColor" strokeWidth="1.4" {...p}>
      <path d="M20.5 6.5a5 5 0 0 0-6.7 6.7L6.5 20.5 11.5 25.5l7.3-7.3A5 5 0 0 0 25.5 11.5L22 15l-5-5 3.5-3.5Z" />
    </svg>
  ),
  plant: (p) => (
    <svg viewBox="0 0 32 32" fill="none" stroke="currentColor" strokeWidth="1.4" {...p}>
      <path d="M8 26V12h4v14M16 26V8h4v18M24 26V14h4v12M6 26h20" />
      <circle cx="10" cy="8" r="2" />
      <circle cx="18" cy="5" r="2" />
    </svg>
  ),
  bolt: (p) => (
    <svg viewBox="0 0 32 32" fill="none" stroke="currentColor" strokeWidth="1.4" {...p}>
      <path d="M8 18h6l-2 10 12-14h-6l2-10L8 18Z" />
    </svg>
  ),
  gear: (p) => (
    <svg viewBox="0 0 32 32" fill="none" stroke="currentColor" strokeWidth="1.4" {...p}>
      <circle cx="16" cy="16" r="4" />
      <path d="M16 6v3M16 23v3M6 16h3M23 16h3M8.8 8.8l2.1 2.1M21.1 21.1l2.1 2.1M23.2 8.8l-2.1 2.1M10.9 21.1l-2.1 2.1" />
    </svg>
  ),
  tool: (p) => (
    <svg viewBox="0 0 32 32" fill="none" stroke="currentColor" strokeWidth="1.4" {...p}>
      <rect x="6" y="14" width="20" height="6" rx="1" />
      <path d="M10 14V10h12v4M12 20v4M20 20v4" />
    </svg>
  ),
  lab: (p) => (
    <svg viewBox="0 0 32 32" fill="none" stroke="currentColor" strokeWidth="1.4" {...p}>
      <path d="M12 6v9l-5 9h18l-5-9V6" />
      <path d="M11 6h10M11 15h10" />
    </svg>
  ),
};

export function ServiceIcon({ name, className }: { name: string; className?: string }) {
  const Icon = icons[name] ?? icons.gear;
  return <Icon className={className} aria-hidden />;
}
