import { Link } from "@tanstack/react-router";
import { Logo } from "@/components/brand/Logo";
import { useI18n } from "@/lib/i18n";

const CAP = [
  { href: "/navvab", key: "n1" as const },
  { href: "/maintenance", key: "n2" as const },
  { href: "/parts", key: "n3" as const },
  { href: "/rd", key: "n4" as const },
];

const NAV = [
  { href: "/", key: "home" as const },
  { href: "/about", key: "about" as const },
  { href: "/services", key: "services" as const },
  { href: "/navvab", key: "navvab" as const },
  { href: "/projects", key: "projects" as const },
  { href: "/knowledge", key: "knowledge" as const },
  { href: "/contact", key: "contact" as const },
];

export function Footer() {
  const { t } = useI18n();
  return (
    <footer className="site-footer relative overflow-hidden bg-navy text-cream">
      <div className="glow-orb -left-24 -top-24 size-[420px] glow-breathe" />
      <div className="glow-orb-amber bottom-0 right-10 size-[180px] opacity-50" />
      <div className="relative mx-auto grid max-w-7xl gap-12 px-5 py-16 lg:grid-cols-12 lg:px-8 lg:py-20">
        <div className="lg:col-span-5">
          <Logo light />
          <p className="mt-5 max-w-sm text-[15px] leading-[1.85] text-cream/70">{t.manifesto}</p>
          <p className="mt-6 max-w-sm text-[14px] leading-[1.85] text-cream/75">{t.address}</p>
          <p className="mt-1 text-[13px] text-cream/50">{t.postal}</p>
        </div>
        <div className="grid gap-10 sm:grid-cols-3 lg:col-span-7">
          <div>
            <p className="text-xs tracking-widest text-cream/45">{t.site}</p>
            <ul className="mt-4 space-y-2.5">
              {NAV.map((n) => (
                <li key={n.href}>
                  <Link to={n.href} viewTransition className="text-[14px] text-cream/80 hover:text-cream">
                    {t.nav[n.key]}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <p className="text-xs tracking-widest text-cream/45">{t.capabilities}</p>
            <ul className="mt-4 space-y-2.5">
              {CAP.map((s) => (
                <li key={s.href}>
                  <Link to={s.href as "/"} viewTransition className="text-[14px] text-cream/80 hover:text-cream">
                    {t.cards[s.key]}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <p className="text-xs tracking-widest text-cream/45">{t.connect}</p>
            <ul className="mt-4 space-y-2.5 text-[14px] text-cream/80">
              <li>
                <Link to="/contact" viewTransition className="hover:text-cream">
                  {t.nav.contact}
                </Link>
              </li>
              <li>
                <Link to="/navvab" viewTransition className="hover:text-cream">
                  {t.device}
                </Link>
              </li>
              <li>
                <Link to="/rd" viewTransition className="hover:text-cream">
                  {t.idea}
                </Link>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div className="relative border-t border-white/8">
        <div className="mx-auto px-5 py-6 text-center text-[13px] text-cream/55 lg:px-8">
          <p>{t.copyright}</p>
        </div>
      </div>
    </footer>
  );
}
