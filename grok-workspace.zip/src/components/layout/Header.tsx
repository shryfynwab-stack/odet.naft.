import { Link, useRouterState } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Logo } from "@/components/brand/Logo";
import { LangSwitch } from "@/components/layout/LangSwitch";
import { cn } from "@/lib/cn";
import { useI18n } from "@/lib/i18n";

const NAV_HREFS = [
  { href: "/", key: "home" },
  { href: "/about", key: "about" },
  { href: "/services", key: "services" },
  { href: "/navvab", key: "navvab" },
  { href: "/projects", key: "projects" },
  { href: "/knowledge", key: "knowledge" },
  { href: "/contact", key: "contact" },
] as const;

export function Header() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [scrolled, setScrolled] = useState(false);
  const isHome = pathname === "/";
  const { t } = useI18n();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={cn(
        "site-header fixed inset-x-0 top-0 z-50 transition-[background-color,border-color,backdrop-filter] duration-300",
        scrolled || !isHome
          ? "border-b border-white/8 bg-navy/94 backdrop-blur-md"
          : "border-b border-white/8 bg-navy/80 backdrop-blur-sm",
      )}
    >
      <div className="mx-auto flex max-w-7xl flex-col gap-1 px-3 py-2.5 md:px-6 lg:h-[72px] lg:flex-row lg:items-center lg:justify-between lg:gap-4 lg:px-8 lg:py-0">
        <div className="flex items-center justify-between gap-3">
          <Logo compact />
          <div className="flex items-center gap-2 lg:hidden">
            <LangSwitch />
            <Link
              to="/contact"
              viewTransition
              className="inline-flex h-9 shrink-0 items-center rounded-md bg-cream px-3 text-[12px] font-medium text-navy transition-transform duration-150 active:scale-[0.96]"
            >
              {t.contactCta}
            </Link>
          </div>
        </div>

        <nav className="flex flex-wrap items-center gap-x-1 gap-y-1 lg:flex-nowrap lg:gap-1" aria-label={t.nav.home}>
          {NAV_HREFS.map((item) => {
            const active = pathname === item.href;
            return (
              <Link
                key={item.href}
                to={item.href}
                viewTransition
                className={cn(
                  "rounded-md px-2 py-1.5 text-[12px] whitespace-nowrap transition-colors duration-150 md:px-2.5 md:text-[13px]",
                  active ? "bg-white/8 text-cream" : "text-cream/82 hover:text-cream",
                )}
              >
                {t.nav[item.key]}
              </Link>
            );
          })}
        </nav>

        <div className="hidden items-center gap-3 lg:flex">
          <LangSwitch />
          <Link
            to="/contact"
            viewTransition
            className="inline-flex h-11 shrink-0 items-center rounded-md bg-cream px-4 text-[13px] font-medium text-navy transition-transform duration-150 active:scale-[0.96]"
          >
            {t.contactCta}
          </Link>
        </div>
      </div>
    </header>
  );
}
