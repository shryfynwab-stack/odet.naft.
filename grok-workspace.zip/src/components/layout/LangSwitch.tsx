import { useId } from "react";
import { cn } from "@/lib/cn";
import { useI18n } from "@/lib/i18n";

export function LangSwitch() {
  const { lang, setLang } = useI18n();
  return (
    <div className="flex items-center gap-1.5" role="group" aria-label="Language">
      <FlagBtn active={lang === "fa"} onClick={() => setLang("fa")} label="فارسی">
        <IranFlag />
      </FlagBtn>
      <FlagBtn active={lang === "en"} onClick={() => setLang("en")} label="English">
        <UkFlag />
      </FlagBtn>
    </div>
  );
}

function FlagBtn({
  active,
  onClick,
  label,
  children,
}: {
  active: boolean;
  onClick: () => void;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      aria-label={label}
      className={cn(
        "grid h-7 w-12 place-items-center overflow-hidden rounded-[2px] ring-1 ring-white/25 transition",
        active ? "ring-2 ring-cream" : "opacity-75 hover:opacity-100",
      )}
    >
      {children}
    </button>
  );
}

function IranFlag() {
  return (
    <img
      src="/images/flag-ir.webp"
      alt=""
      width={40}
      height={24}
      decoding="async"
      className="size-full object-cover outline-none"
    />
  );
}

function UkFlag() {
  const id = useId();
  return (
    <svg viewBox="0 0 60 30" className="size-full" preserveAspectRatio="xMidYMid slice" aria-hidden>
      <clipPath id={id}>
        <path d="M0,0 v30 h60 v-30 z" />
      </clipPath>
      <g clipPath={`url(#${id})`}>
        <path d="M0,0 v30 h60 v-30 z" fill="#012169" />
        <path d="M0,0 L60,30 M60,0 L0,30" stroke="#fff" strokeWidth="6" />
        <path d="M0,0 L60,30 M60,0 L0,30" stroke="#C8102E" strokeWidth="2" />
        <path d="M30,0 v30 M0,15 h60" stroke="#fff" strokeWidth="10" />
        <path d="M30,0 v30 M0,15 h60" stroke="#C8102E" strokeWidth="6" />
      </g>
    </svg>
  );
}
