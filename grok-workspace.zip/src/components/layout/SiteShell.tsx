import { useEffect, useRef, type ReactNode } from "react";
import { useRouterState } from "@tanstack/react-router";
import { Footer } from "./Footer";
import { Header } from "./Header";
import { cn } from "@/lib/cn";
import { useI18n } from "@/lib/i18n";

export function SiteShell({ children }: { children: ReactNode }) {
  const { dir } = useI18n();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const seen = useRef<string | null>(null);
  const animate = seen.current !== null && seen.current !== pathname;
  seen.current = pathname;
  const vt =
    typeof document !== "undefined" && typeof document.startViewTransition === "function";

  useEffect(() => {
    if (animate) window.scrollTo(0, 0);
  }, [pathname, animate]);

  return (
    <div className="min-h-dvh max-w-full overflow-x-clip bg-soft text-ink" dir={dir}>
      <Header />
      {animate && !vt ? <div key={`veil-${pathname}`} className="page-veil" aria-hidden /> : null}
      <main key={pathname} className={cn("site-main", animate && !vt && "page-enter")}>
        {children}
      </main>
      <Footer />
    </div>
  );
}

export function PageHero({
  kicker,
  title,
  lead,
}: {
  kicker: string;
  title: string;
  lead: string;
}) {
  return (
    <section className="relative overflow-hidden bg-navy pt-36 pb-16 text-cream md:pt-40 md:pb-20">
      <div className="site-grid pointer-events-none absolute inset-0 opacity-70" />
      <div className="glow-orb glow-breathe -right-16 top-10 size-[380px]" />
      <div className="glow-orb-amber bottom-0 left-10 size-[180px] opacity-70" />
      <div className="relative mx-auto max-w-7xl px-5 lg:px-8">
        <p className="text-xs tracking-[0.22em] text-teal-soft">{kicker}</p>
        <div className="mt-4 h-px w-16 bg-cream/50 glow-line" />
        <h1 className="ambient-halo mt-6 max-w-4xl text-[40px] font-semibold leading-[1.25] md:text-[56px]">
          {title}
        </h1>
        <p className="mt-5 max-w-2xl text-[16px] leading-[1.85] text-cream/72">{lead}</p>
      </div>
    </section>
  );
}
