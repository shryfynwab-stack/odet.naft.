import { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/cn";

export function CountUp({
  to,
  prefix = "",
  suffix = "",
  className,
  duration = 1400,
}: {
  to: number;
  prefix?: string;
  suffix?: string;
  className?: string;
  duration?: number;
}) {
  const ref = useRef<HTMLSpanElement>(null);
  const [value, setValue] = useState(0);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    let started = false;
    let frame = 0;

    const run = () => {
      if (started) return;
      started = true;
      if (reduced) {
        setValue(to);
        return;
      }
      const start = performance.now();
      const tick = (now: number) => {
        const t = Math.min(1, (now - start) / duration);
        const eased = 1 - (1 - t) ** 3;
        setValue(Math.round(eased * to));
        if (t < 1) frame = requestAnimationFrame(tick);
      };
      frame = requestAnimationFrame(tick);
    };

    const visible = () => {
      const r = el.getBoundingClientRect();
      return r.bottom > 60 && r.top < window.innerHeight - 40;
    };

    const io = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) run();
      },
      { threshold: 0.05, rootMargin: "0px 0px -8% 0px" },
    );
    io.observe(el);
    if (visible()) run();

    const onScroll = () => {
      if (visible()) run();
    };
    window.addEventListener("scroll", onScroll, { passive: true });

    const fallback = window.setTimeout(() => {
      if (visible()) run();
    }, 600);

    return () => {
      io.disconnect();
      window.removeEventListener("scroll", onScroll);
      window.clearTimeout(fallback);
      cancelAnimationFrame(frame);
    };
  }, [to, duration]);

  return (
    <span ref={ref} className={cn("tabular-nums latin", className)}>
      {prefix}
      {value}
      {suffix}
    </span>
  );
}
