import type { ReactNode } from "react";
import { cn } from "@/lib/cn";

export function WordReveal({
  text,
  className,
  delay = 0,
  as: Tag = "h1",
}: {
  text: string;
  className?: string;
  delay?: number;
  as?: "h1" | "h2" | "p" | "span";
}) {
  const words = text.split(" ").filter(Boolean);
  return (
    <Tag className={cn(className)}>
      {words.map((word, i) => (
        <span
          key={`${word}-${i}`}
          className="word-reveal"
          style={{ animationDelay: `${delay + i * 80}ms` }}
        >
          {word}
          {i < words.length - 1 ? "\u00A0" : ""}
        </span>
      ))}
    </Tag>
  );
}

export function LineReveal({
  children,
  className,
  delay = 0,
  as: Tag = "p",
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
  as?: "p" | "div" | "h2" | "h3" | "span";
}) {
  return (
    <Tag className={cn("line-reveal", className)} style={{ animationDelay: `${delay}ms` }}>
      {children}
    </Tag>
  );
}
