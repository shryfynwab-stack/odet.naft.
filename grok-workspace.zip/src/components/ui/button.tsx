import { Link } from "@tanstack/react-router";
import { cva, type VariantProps } from "class-variance-authority";
import type { ButtonHTMLAttributes, ReactNode } from "react";
import { cn } from "@/lib/cn";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 rounded-md text-[15px] font-medium transition-[transform,background-color,color,border-color,box-shadow] duration-150 ease-out active:not-disabled:scale-[0.96] disabled:opacity-50",
  {
    variants: {
      variant: {
        amber:
          "bg-amber text-cream hover:brightness-110 shadow-[0_0_0_1px_rgba(186,65,23,0.18)]",
        ghost:
          "border border-cream/30 bg-transparent text-cream hover:border-cream hover:text-cream",
        navy: "bg-navy text-cream hover:bg-navy-mid",
        outline:
          "border border-navy/15 bg-transparent text-navy hover:border-navy hover:text-navy-deep",
        teal: "bg-navy-mid text-cream hover:brightness-110",
      },
      size: {
        md: "h-12 min-h-11 px-6",
        lg: "h-14 min-h-11 px-8 text-base",
        sm: "h-11 min-h-11 px-4 text-sm",
      },
    },
    defaultVariants: { variant: "navy", size: "md" },
  },
);

type Props = ButtonHTMLAttributes<HTMLButtonElement> &
  VariantProps<typeof buttonVariants> & {
    href?: string;
    children: ReactNode;
  };

export function Button({ className, variant, size, href, children, ...props }: Props) {
  const cls = cn(buttonVariants({ variant, size }), className);
  if (href) {
    return (
      <Link to={href as "/"} viewTransition className={cls}>
        {children}
      </Link>
    );
  }
  return (
    <button className={cls} {...props}>
      {children}
    </button>
  );
}
