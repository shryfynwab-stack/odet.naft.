const SRC = "/audio/background.m4a";
const VOLUME = 0.15;

let audio: HTMLAudioElement | null = null;

function ensure() {
  if (typeof window === "undefined") return null;
  if (!audio) {
    audio = new Audio();
    audio.loop = true;
    audio.volume = VOLUME;
    audio.preload = "none";
  }
  if (!audio.src) audio.src = SRC;
  return audio;
}

export function ambientIsOn() {
  return !!audio && !!audio.src && !audio.paused;
}

export async function playAmbient() {
  const a = ensure();
  if (!a) return false;
  a.volume = VOLUME;
  try {
    await a.play();
    sessionStorage.setItem("kavosh-audio", "on");
    return true;
  } catch {
    return false;
  }
}

export function pauseAmbient() {
  if (!audio) return;
  audio.pause();
  sessionStorage.setItem("kavosh-audio", "off");
}
