import { createRootRoute, HeadContent, Outlet, Scripts } from "@tanstack/react-router";
import { AmbientAudio } from "@/components/audio/AmbientAudio";
import { PreviewHostBridge } from "@/components/preview-host-bridge";
import { SiteShell } from "@/components/layout/SiteShell";
import { AuthProvider } from "@/lib/auth/provider";
import { LanguageProvider } from "@/lib/i18n";
import appCss from "../styles.css?url";

const APP_NAME = "کاوشگران فنون توسعه نفت";

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: APP_NAME },
      { name: "theme-color", content: "#3c513e" },
      {
        name: "description",
        content:
          "کاوشگران فنون توسعه نفت — تجربه صنعت، توسعه فناوری. خدمات فنی، تعمیرات و تجهیزات تخصصی برند Navvab.",
      },
    ],
    links: [
      { rel: "icon", type: "image/svg+xml", href: "/favicon.svg" },
      { rel: "preload", as: "image", href: "/images/hero.webp", fetchPriority: "high" },
      { rel: "preload", as: "font", href: "/fonts/arabic-400-arabic.woff2", type: "font/woff2", crossOrigin: "anonymous" },
      { rel: "preload", as: "font", href: "/fonts/arabic-600-arabic.woff2", type: "font/woff2", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: appCss },
      { rel: "manifest", href: "/__grok/manifest.webmanifest" },
      { rel: "apple-touch-icon", href: "/__grok/icon-180.png" },
    ],
  }),
  component: () => (
    <html lang="fa" dir="rtl" suppressHydrationWarning className="antialiased">
      <head>
        <HeadContent />
      </head>
      <body>
        <PreviewHostBridge />
        <AuthProvider>
          <LanguageProvider>
            <AmbientAudio />
            <SiteShell>
              <Outlet />
            </SiteShell>
          </LanguageProvider>
        </AuthProvider>
        <Scripts />
      </body>
    </html>
  ),
});
