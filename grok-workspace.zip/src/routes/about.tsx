import { createFileRoute } from "@tanstack/react-router";
import { FinalCta } from "@/components/home/FinalCta";
import { PageHero } from "@/components/layout/SiteShell";
import { Reveal } from "@/components/motion/Reveal";
import { Button } from "@/components/ui/button";
import { useI18n } from "@/lib/i18n";
import { PROJECTS } from "@/lib/site";

export const Route = createFileRoute("/about")({ component: AboutPage });

function AboutPage() {
  const { t } = useI18n();
  const a = t.about;
  return (
    <>
      <PageHero kicker={a.kicker} title={a.title} lead={a.lead} />
      <section className="bg-soft py-20 md:py-28">
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-5 lg:grid-cols-12 lg:px-8">
          <Reveal className="space-y-5 text-[16px] leading-[1.9] text-ink/80 lg:col-span-7 md:text-[17px]">
            <p>{a.p1}</p>
            <p className="text-[20px] font-medium text-navy">{a.quote}</p>
            <p>{a.p2}</p>
            <p>{a.p3}</p>
          </Reveal>
          <Reveal delay={100} className="lg:col-span-5">
            <img src="/images/reactor-2.webp" alt="" loading="lazy" decoding="async" className="aspect-[4/5] w-full rounded-xl object-cover" />
          </Reveal>
        </div>
      </section>

      <section className="bg-cream py-20 md:py-28">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <Reveal>
            <p className="text-xs tracking-[0.2em] text-teal">{a.pathK}</p>
            <h2 className="mt-4 text-[32px] font-semibold text-navy md:text-[44px]">{a.pathT}</h2>
            <p className="mt-5 max-w-2xl text-[16px] leading-[1.9] text-ink/75">{a.pathL}</p>
          </Reveal>
          <ol className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {a.steps.map((s, i) => (
              <Reveal key={s} delay={i * 50} as="li" className="rounded-xl bg-soft p-6">
                <p className="latin text-teal">{String(i + 1).padStart(2, "0")}</p>
                <p className="mt-3 text-[20px] font-medium text-navy">{s}</p>
              </Reveal>
            ))}
          </ol>
        </div>
      </section>

      <section className="bg-soft py-20 md:py-28">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <Reveal>
            <p className="text-xs tracking-[0.2em] text-teal">{a.whyK}</p>
            <h2 className="mt-4 text-[32px] font-semibold text-navy md:text-[44px]">{a.whyT}</h2>
          </Reveal>
          <div className="mt-12 grid gap-10 md:grid-cols-2 lg:grid-cols-3">
            {a.why.map((w, i) => (
              <Reveal key={w.t} delay={i * 60}>
                <h3 className="text-[22px] font-medium text-navy">{w.t}</h3>
                <p className="mt-3 text-[15px] leading-[1.85] text-ink/70">{w.b}</p>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="relative overflow-hidden">
        <img src="/images/night.webp" alt="" loading="lazy" decoding="async" className="absolute inset-0 size-full object-cover" />
        <div className="absolute inset-0 bg-navy/78" />
        <div className="relative mx-auto max-w-7xl px-5 py-24 lg:px-8 md:py-32">
          <Reveal>
            <p className="text-xs tracking-[0.2em] text-teal-soft">{a.visK}</p>
            <h2 className="ambient-halo mt-5 max-w-4xl text-[32px] font-semibold leading-[1.35] text-cream md:text-[48px]">
              {a.visT}
            </h2>
            <p className="mt-8 max-w-2xl text-[16px] leading-[1.9] text-cream/75">{a.vis1}</p>
            <p className="mt-6 max-w-2xl text-[16px] leading-[1.9] text-cream/75">{a.vis2}</p>
          </Reveal>
        </div>
      </section>

      <section className="bg-cream py-20 md:py-28">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <Reveal className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
            <div>
              <p className="text-xs tracking-[0.2em] text-teal">{a.projK}</p>
              <h2 className="mt-4 text-[32px] font-semibold text-navy md:text-[44px]">{a.projT}</h2>
            </div>
            <Button href="/projects" variant="outline">
              {a.projAll}
            </Button>
          </Reveal>
          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {PROJECTS.map((p, i) => (
              <Reveal key={p.name} delay={i * 50} as="article" className="overflow-hidden rounded-xl bg-soft">
                <img src={p.img} alt="" loading="lazy" decoding="async" className="aspect-[16/10] w-full object-cover" />
                <div className="p-5">
                  <p className="text-[12px] text-teal">{t.projects.items[i].tag}</p>
                  <h3 className="mt-1 text-[18px] font-medium text-navy">{t.projects.items[i].name}</h3>
                  <p className="mt-1 text-[13px] text-muted">{t.projects.items[i].place}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>
      <FinalCta />
    </>
  );
}
