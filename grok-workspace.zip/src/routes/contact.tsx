import { createFileRoute } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { PageHero } from "@/components/layout/SiteShell";
import { Reveal } from "@/components/motion/Reveal";
import { Button } from "@/components/ui/button";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/contact")({ component: ContactPage });

function ContactPage() {
  const { t } = useI18n();
  const c = t.contact;
  const [sent, setSent] = useState(false);

  function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const data = Object.fromEntries(new FormData(form).entries());
    const prev = JSON.parse(localStorage.getItem("kavosh-inquiries") || "[]") as unknown[];
    prev.push({ ...data, at: new Date().toISOString() });
    localStorage.setItem("kavosh-inquiries", JSON.stringify(prev));
    setSent(true);
    form.reset();
  }

  return (
    <>
      <PageHero kicker={c.kicker} title={c.title} lead={c.lead} />
      <section className="bg-soft py-16 md:py-24">
        <div className="mx-auto grid max-w-7xl gap-12 px-5 lg:grid-cols-12 lg:px-8">
          <Reveal className="lg:col-span-5">
            <h2 className="text-[28px] font-semibold text-navy">{t.company}</h2>
            <p className="mt-4 text-[16px] leading-[1.9] text-ink/75">{t.manifesto}</p>
            <div className="mt-8 space-y-2 text-[15px] leading-[1.85] text-ink/80">
              <p className="font-medium text-navy">{c.addr}</p>
              <p>{t.address}</p>
              <p>{t.postal}</p>
            </div>
            <p className="mt-8 text-[15px] leading-[1.85] text-ink/70">{c.formLead}</p>
            <img src="/images/piping.webp" alt="" loading="lazy" decoding="async" className="mt-10 aspect-[16/10] w-full rounded-xl object-cover" />
          </Reveal>
          <Reveal delay={80} className="lg:col-span-7">
            {sent ? (
              <div className="rounded-xl bg-cream p-8 md:p-10">
                <p className="text-[22px] font-medium text-navy">{c.sentT}</p>
                <p className="mt-3 text-[15px] leading-[1.85] text-ink/70">{c.sent}</p>
                <button type="button" className="mt-6 text-[14px] text-navy" onClick={() => setSent(false)}>
                  {c.again}
                </button>
              </div>
            ) : (
              <form onSubmit={onSubmit} className="rounded-xl bg-cream p-6 shadow-[var(--shadow-card)] md:p-10">
                <div className="grid gap-5 md:grid-cols-2">
                  <Field name="name" label={c.name} required />
                  <Field name="org" label={c.org} />
                  <Field name="phone" label={c.phone} type="tel" required />
                  <Field name="email" label={c.email} type="email" />
                </div>
                <label className="mt-5 block">
                  <span className="text-[13px] text-muted">{c.topic}</span>
                  <select
                    name="topic"
                    className="mt-1.5 h-12 w-full rounded-md border-0 bg-soft px-3 text-[15px] text-navy outline-none ring-1 ring-navy/10 focus:ring-2 focus:ring-navy"
                    defaultValue={c.topics[0]}
                  >
                    {c.topics.map((opt) => (
                      <option key={opt}>{opt}</option>
                    ))}
                  </select>
                </label>
                <label className="mt-5 block">
                  <span className="text-[13px] text-muted">{c.msg}</span>
                  <textarea
                    name="message"
                    required
                    rows={6}
                    className="mt-1.5 w-full rounded-md border-0 bg-soft px-3 py-3 text-[15px] leading-[1.8] text-navy outline-none ring-1 ring-navy/10 focus:ring-2 focus:ring-navy"
                  />
                </label>
                <div className="mt-6">
                  <Button type="submit" variant="navy" size="lg">
                    {c.send}
                  </Button>
                </div>
              </form>
            )}
          </Reveal>
        </div>
      </section>
    </>
  );
}

function Field({
  name,
  label,
  type = "text",
  required,
}: {
  name: string;
  label: string;
  type?: string;
  required?: boolean;
}) {
  return (
    <label className="block">
      <span className="text-[13px] text-muted">{label}</span>
      <input
        name={name}
        type={type}
        required={required}
        className="mt-1.5 h-12 w-full rounded-md border-0 bg-soft px-3 text-[15px] text-navy outline-none ring-1 ring-navy/10 focus:ring-2 focus:ring-navy"
      />
    </label>
  );
}
