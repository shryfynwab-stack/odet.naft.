import { createFileRoute } from "@tanstack/react-router";
import { FinalCta } from "@/components/home/FinalCta";
import { PageHero } from "@/components/layout/SiteShell";
import { Reveal } from "@/components/motion/Reveal";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/knowledge")({ component: KnowledgePage });

function KnowledgePage() {
  const { t } = useI18n();
  return (
    <>
      <PageHero kicker={t.knowledge.kicker} title={t.knowledge.title} lead={t.knowledge.lead} />
      <section className="bg-soft py-20 md:py-28">
        <div className="mx-auto grid max-w-7xl gap-16 px-5 lg:grid-cols-12 lg:px-8">
          <Reveal className="lg:col-span-7 space-y-6 text-[16px] leading-[1.9] text-ink/80">
            <p>{t.about.vis1}</p>
            <p>{t.about.vis2}</p>
            <p className="text-[22px] font-medium text-navy">{t.navvab.bridge}</p>
          </Reveal>
          <Reveal delay={80} className="lg:col-span-5">
            <img src="/images/rd.webp" alt="" loading="lazy" decoding="async" className="w-full rounded-xl object-cover" />
          </Reveal>
        </div>
      </section>
      <FinalCta />
    </>
  );
}
