import { createFileRoute } from "@tanstack/react-router";
import { FinalCta } from "@/components/home/FinalCta";
import { PageHero } from "@/components/layout/SiteShell";
import { Reveal } from "@/components/motion/Reveal";
import { Button } from "@/components/ui/button";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/maintenance")({ component: MaintenancePage });

function MaintenancePage() {
  const { t } = useI18n();
  const m = t.maint;
  return (
    <>
      <PageHero kicker={m.kicker} title={m.title} lead={m.lead} />
      <section className="bg-soft py-20 md:py-28">
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-5 lg:grid-cols-12 lg:px-8">
          <Reveal className="lg:col-span-7 space-y-5 text-[16px] leading-[1.9] text-ink/80">
            <p>{m.p1}</p>
            <p className="text-[20px] font-medium text-navy">{m.areasT}</p>
            <ul className="space-y-2">
              {m.areas.map((a) => (
                <li key={a} className="flex gap-3">
                  <span className="mt-2 size-1.5 shrink-0 rounded-full bg-amber" />
                  <span>{a}</span>
                </li>
              ))}
            </ul>
          </Reveal>
          <Reveal delay={80} className="lg:col-span-5">
            <img src="/images/piping.webp" alt="" loading="lazy" decoding="async" className="w-full rounded-xl object-cover" />
          </Reveal>
        </div>
      </section>
      <section className="bg-cream py-20 md:py-28">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <Reveal className="max-w-3xl">
            <p className="text-xs tracking-[0.2em] text-teal">{m.appK}</p>
            <h2 className="mt-4 text-[32px] font-semibold text-navy md:text-[44px]">{m.appT}</h2>
            <p className="mt-6 text-[16px] leading-[1.9] text-ink/80">{m.app1}</p>
            <p className="mt-5 text-[16px] leading-[1.9] text-ink/80">{m.app2}</p>
            <div className="mt-10">
              <Button href="/contact" variant="navy">
                {m.btn}
              </Button>
            </div>
          </Reveal>
        </div>
      </section>
      <FinalCta />
    </>
  );
}
