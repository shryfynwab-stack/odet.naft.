import { createFileRoute } from "@tanstack/react-router";
import { FinalCta } from "@/components/home/FinalCta";
import { PageHero } from "@/components/layout/SiteShell";
import { Reveal } from "@/components/motion/Reveal";
import { Button } from "@/components/ui/button";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/navvab")({ component: NavvabPage });

function NavvabPage() {
  const { t } = useI18n();
  const n = t.navvab;
  return (
    <>
      <PageHero kicker={n.kicker} title={n.title} lead={n.lead} />

      <section className="bg-cream py-16 md:py-20">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <Reveal>
            <p className="text-xs tracking-[0.2em] text-teal">{n.bridgeK}</p>
            <h2 className="mt-4 max-w-3xl text-[32px] font-semibold text-navy md:text-[44px]">{n.bridgeT}</h2>
            <p className="mt-5 max-w-2xl text-[18px] font-medium text-navy">{n.bridge}</p>
          </Reveal>
        </div>
      </section>

      <section className="bg-soft py-20 md:py-28">
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-5 lg:grid-cols-2 lg:px-8">
          <Reveal>
            <p className="text-xs tracking-[0.2em] text-teal">{n.flag}</p>
            <h2 className="mt-4 text-[32px] font-semibold leading-[1.3] text-navy md:text-[44px]">{n.h}</h2>
            <p className="mt-5 text-[18px] font-medium text-navy">{n.sub}</p>
            <div className="mt-6 space-y-4 text-[16px] leading-[1.9] text-ink/78">
              <p>{n.p1}</p>
              <p>{n.p2}</p>
            </div>
          </Reveal>
          <Reveal delay={80} className="relative">
            <div className="glow-orb -left-6 top-8 size-52" />
            <img src="/images/reactor-1.webp" alt="" loading="lazy" decoding="async" className="relative aspect-[4/3] w-full rounded-xl object-cover" />
          </Reveal>
        </div>
      </section>

      <section className="bg-cream py-20 md:py-28">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <Reveal>
            <p className="text-xs tracking-[0.2em] text-teal">{n.qK}</p>
            <h2 className="mt-4 max-w-3xl text-[32px] font-semibold text-navy md:text-[44px]">{n.qT}</h2>
            <p className="mt-6 max-w-2xl text-[16px] leading-[1.9] text-ink/80">{n.qL}</p>
          </Reveal>
          <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {n.challenges.map((c, i) => (
              <Reveal key={c} delay={i * 50} className="rounded-xl bg-soft p-5">
                <p className="latin text-[12px] text-teal">{String(i + 1).padStart(2, "0")}</p>
                <p className="mt-2 text-[16px] font-medium text-navy">{c}</p>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="relative overflow-hidden bg-navy py-20 text-cream md:py-28">
        <div className="glow-orb glow-breathe right-0 top-0 size-[420px]" />
        <div className="relative mx-auto max-w-7xl px-5 lg:px-8">
          <Reveal>
            <p className="text-xs tracking-[0.2em] text-teal-soft">{n.solK}</p>
            <h2 className="ambient-halo mt-4 text-[32px] font-semibold md:text-[44px]">{n.solT}</h2>
            <p className="mt-6 max-w-2xl text-[16px] leading-[1.9] text-cream/75">{n.sol}</p>
          </Reveal>
        </div>
      </section>

      <section className="bg-cream py-20 md:py-28">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <Reveal>
            <h2 className="text-[32px] font-semibold text-navy md:text-[44px]">{n.featT}</h2>
          </Reveal>
          <ul className="mt-10 grid gap-3 md:grid-cols-2">
            {n.features.map((f) => (
              <li key={f} className="flex gap-3 text-[15px] leading-[1.8] text-ink/80">
                <span className="mt-2 size-1.5 shrink-0 rounded-full bg-amber" />
                {f}
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className="bg-navy py-20 text-cream md:py-28">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <Reveal>
            <h2 className="ambient-halo text-[32px] font-semibold md:text-[44px]">{n.resT}</h2>
            <p className="mt-5 max-w-2xl text-[16px] leading-[1.9] text-cream/70">{n.resL}</p>
          </Reveal>
          <div className="mt-12 grid gap-8 sm:grid-cols-3">
            {[
              { k: n.time, a: n.timeA, b: n.timeB },
              { k: n.man, a: n.manA, b: n.manB },
              { k: n.multi, a: n.multiA, b: n.multiB },
            ].map((x, i) => (
              <Reveal key={x.k} delay={i * 80} className="rounded-xl border border-white/8 p-6">
                <p className="text-[13px] text-cream/50">{x.k}</p>
                <p className="mt-4 text-[15px] text-cream/45 line-through">{x.a}</p>
                <p className="mt-1 text-[28px] font-semibold text-cream">{x.b}</p>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-soft py-20 md:py-28">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <Reveal>
            <h2 className="text-[32px] font-semibold text-navy md:text-[48px]">{n.valT}</h2>
            <p className="mt-6 max-w-2xl text-[16px] leading-[1.9] text-ink/80">{n.val}</p>
          </Reveal>
          <div className="mt-14 grid gap-8 md:grid-cols-2">
            <Reveal className="rounded-xl bg-cream p-8">
              <h3 className="text-[22px] font-medium text-navy">{n.buyT}</h3>
              <p className="mt-4 text-[15px] leading-[1.85] text-ink/75">{n.buy}</p>
              <div className="mt-6">
                <Button href="/contact" variant="navy">
                  {n.buyBtn}
                </Button>
              </div>
            </Reveal>
            <Reveal delay={80} className="rounded-xl bg-cream p-8">
              <h3 className="text-[22px] font-medium text-navy">{n.runT}</h3>
              <p className="mt-4 text-[15px] leading-[1.85] text-ink/75">{n.run}</p>
              <div className="mt-6">
                <Button href="/contact" variant="outline">
                  {n.runBtn}
                </Button>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      <section className="bg-cream py-16">
        <div className="mx-auto grid max-w-7xl gap-6 px-5 md:grid-cols-3 lg:px-8">
          <img src="/images/reactor-1.webp" alt="" loading="lazy" decoding="async" className="aspect-[4/3] w-full rounded-xl object-cover" />
          <img src="/images/reactor-2.webp" alt="" loading="lazy" decoding="async" className="aspect-[4/3] w-full rounded-xl object-cover" />
          <img src="/images/sieve.webp" alt="" loading="lazy" decoding="async" className="aspect-[4/3] w-full rounded-xl object-cover" />
        </div>
      </section>
      <FinalCta />
    </>
  );
}
