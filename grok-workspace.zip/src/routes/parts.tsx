import { createFileRoute } from "@tanstack/react-router";
import { FinalCta } from "@/components/home/FinalCta";
import { PageHero } from "@/components/layout/SiteShell";
import { Reveal } from "@/components/motion/Reveal";
import { Button } from "@/components/ui/button";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/parts")({ component: PartsPage });

function PartsPage() {
  const { t } = useI18n();
  const p = t.parts;
  return (
    <>
      <PageHero kicker={p.kicker} title={p.title} lead={p.lead} />
      <section className="bg-soft py-20 md:py-28">
        <div className="mx-auto grid max-w-7xl gap-12 px-5 lg:grid-cols-12 lg:px-8">
          <Reveal className="lg:col-span-7 space-y-5 text-[16px] leading-[1.9] text-ink/80">
            <p>{p.p1}</p>
            <p className="text-[20px] font-medium text-navy">{p.areasT}</p>
            <ul className="space-y-2">
              {p.areas.map((a) => (
                <li key={a} className="flex gap-3">
                  <span className="mt-2 size-1.5 shrink-0 rounded-full bg-amber" />
                  <span>{a}</span>
                </li>
              ))}
            </ul>
          </Reveal>
          <Reveal delay={80} className="lg:col-span-5">
            <img src="/images/workshop.webp" alt="" loading="lazy" decoding="async" className="w-full rounded-xl object-cover" />
          </Reveal>
        </div>
      </section>
      <section className="bg-cream py-20 md:py-28">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <Reveal>
            <h2 className="text-[32px] font-semibold text-navy md:text-[44px]">{p.revT}</h2>
            <p className="mt-6 max-w-3xl text-[16px] leading-[1.9] text-ink/80">{p.rev1}</p>
            <p className="mt-5 max-w-3xl text-[16px] leading-[1.9] text-ink/80">{p.rev2}</p>
          </Reveal>
          <Reveal className="mt-14">
            <p className="text-xs tracking-[0.2em] text-teal">{p.pathK}</p>
            <ol className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {p.path.map((s, i) => (
                <li key={s} className="rounded-xl bg-soft p-5">
                  <p className="latin text-teal">{String(i + 1).padStart(2, "0")}</p>
                  <p className="mt-2 text-[17px] font-medium text-navy">{s}</p>
                </li>
              ))}
            </ol>
          </Reveal>
          <Reveal className="mt-12 max-w-3xl">
            <p className="text-[16px] leading-[1.9] text-ink/80">{p.app}</p>
            <div className="mt-8">
              <Button href="/contact" variant="navy">
                {p.btn}
              </Button>
            </div>
          </Reveal>
        </div>
      </section>
      <FinalCta />
    </>
  );
}
