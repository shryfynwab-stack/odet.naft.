import { createFileRoute } from "@tanstack/react-router";
import { FinalCta } from "@/components/home/FinalCta";
import { PageHero } from "@/components/layout/SiteShell";
import { Reveal } from "@/components/motion/Reveal";
import { useI18n } from "@/lib/i18n";
import { PROJECTS } from "@/lib/site";

export const Route = createFileRoute("/projects")({ component: ProjectsPage });

function ProjectsPage() {
  const { t } = useI18n();
  return (
    <>
      <PageHero kicker={t.projects.kicker} title={t.projects.title} lead={t.projects.lead} />
      <section className="bg-soft py-16 md:py-24">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <div className="grid gap-6 md:grid-cols-2">
            {PROJECTS.map((p, i) => (
              <Reveal key={p.name} delay={i * 50} as="article" className="overflow-hidden rounded-xl bg-cream shadow-[var(--shadow-card)]">
                <img src={p.img} alt="" loading="lazy" decoding="async" className="aspect-[16/9] w-full object-cover" />
                <div className="p-6 md:p-8">
                  <p className="text-[12px] text-teal">{t.projects.items[i].tag}</p>
                  <h2 className="mt-2 text-[24px] font-medium text-navy md:text-[28px]">{t.projects.items[i].name}</h2>
                  <p className="mt-2 text-[14px] text-muted">{t.projects.items[i].place}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>
      <FinalCta />
    </>
  );
}
