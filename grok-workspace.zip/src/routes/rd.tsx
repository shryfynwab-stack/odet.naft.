import { createFileRoute } from "@tanstack/react-router";
import { FinalCta } from "@/components/home/FinalCta";
import { PageHero } from "@/components/layout/SiteShell";
import { Reveal } from "@/components/motion/Reveal";
import { Button } from "@/components/ui/button";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/rd")({ component: RdPage });

function RdPage() {
  const { t } = useI18n();
  const r = t.rd;
  return (
    <>
      <PageHero kicker={r.kicker} title={r.title} lead={r.lead} />
      <section className="bg-soft py-20 md:py-28">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <Reveal className="max-w-3xl space-y-5 text-[16px] leading-[1.9] text-ink/80">
            <p>{r.p1}</p>
            <p>{r.p2}</p>
            <p>{r.p3}</p>
            <p>{r.p4}</p>
          </Reveal>
        </div>
      </section>
      <section className="bg-cream py-20 md:py-28">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <Reveal>
            <p className="text-xs tracking-[0.2em] text-teal">{r.pathK}</p>
            <ol className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {r.path.map((s, i) => (
                <li key={s} className="rounded-xl bg-soft p-5">
                  <p className="latin text-teal">{String(i + 1).padStart(2, "0")}</p>
                  <p className="mt-2 text-[17px] font-medium text-navy">{s}</p>
                </li>
              ))}
            </ol>
          </Reveal>
          <Reveal className="mt-16">
            <h2 className="text-[28px] font-semibold text-navy">{r.axT}</h2>
            <ul className="mt-6 grid gap-3 md:grid-cols-2">
              {r.axes.map((a) => (
                <li key={a} className="flex gap-3 text-[15px] leading-[1.8] text-ink/80">
                  <span className="mt-2 size-1.5 shrink-0 rounded-full bg-amber" />
                  {a}
                </li>
              ))}
            </ul>
          </Reveal>
        </div>
      </section>
      <section className="relative overflow-hidden bg-navy py-20 text-cream md:py-28">
        <div className="relative mx-auto max-w-7xl px-5 lg:px-8">
          <Reveal>
            <h2 className="ambient-halo text-[32px] font-semibold md:text-[44px]">{r.ideaT}</h2>
            <p className="mt-6 max-w-2xl text-[16px] leading-[1.9] text-cream/75">{r.idea}</p>
            <p className="mt-5 max-w-2xl text-[18px] font-medium">{r.ideaQ}</p>
            <div className="mt-8">
              <Button href="/contact" variant="navy" className="bg-cream text-navy hover:bg-cream/90" size="lg">
                {r.ideaBtn}
              </Button>
            </div>
          </Reveal>
        </div>
      </section>
      <section className="bg-soft py-20 md:py-28">
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-5 lg:grid-cols-2 lg:px-8">
          <Reveal>
            <p className="text-xs tracking-[0.2em] text-teal">{r.sampleK}</p>
            <h2 className="mt-4 text-[28px] font-semibold text-navy md:text-[36px]">{t.device}</h2>
            <p className="mt-5 text-[16px] leading-[1.9] text-ink/80">{r.sample}</p>
            <p className="mt-5 text-[16px] leading-[1.9] text-ink/80">{r.sample2}</p>
            <div className="mt-8">
              <Button href="/navvab" variant="outline">
                Navvab
              </Button>
            </div>
          </Reveal>
          <Reveal delay={80}>
            <img src="/images/device.webp" alt="" loading="lazy" decoding="async" className="w-full rounded-xl object-cover" />
          </Reveal>
        </div>
      </section>
      <FinalCta />
    </>
  );
}
