import { createFileRoute } from "@tanstack/react-router";
import { BuildCards } from "@/components/home/BuildCards";
import { FinalCta } from "@/components/home/FinalCta";
import { PageHero } from "@/components/layout/SiteShell";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/services")({ component: ServicesPage });

function ServicesPage() {
  const { t } = useI18n();
  return (
    <>
      <PageHero kicker={t.services.kicker} title={t.services.title} lead={t.services.lead} />
      <BuildCards />
      <FinalCta />
    </>
  );
}
